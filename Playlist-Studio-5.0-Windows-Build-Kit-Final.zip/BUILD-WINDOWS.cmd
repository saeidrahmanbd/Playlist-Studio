@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Keep the build console open even when this file is double-clicked.
if /I not "%PS5_BUILD_WINDOW%"=="1" (
  set "PS5_BUILD_WINDOW=1"
  start "Playlist Studio 5.0 - Windows Builder" cmd.exe /k call "%~f0" %*
  exit /b 0
)

cd /d "%~dp0"
title Playlist Studio 5.0 - BDIX-IPTV Builder
set "LOG=%~dp0BUILD-LOG.txt"
>"%LOG%" echo Playlist Studio 5.0 build log
>>"%LOG%" echo Started: %date% %time%

cls
echo.
echo  Playlist Studio 5.0 - BDIX-IPTV
echo =================================
echo  Windows x64 single-file build
echo.
echo  This window will stay open if anything fails.
echo  Log: %LOG%
echo.

call :step "Checking Python launcher..."
where py >nul 2>nul
if errorlevel 1 (
  call :fail "Python launcher (py) was not found. Install 64-bit Python 3.12+ and try again."
  goto :done
)
py -3 -c "import sys; print('Python:',sys.version); print('Architecture:',sys.maxsize.bit_length()+1,'bit'); assert sys.maxsize > 2**32 and sys.version_info >= (3,12)"
if errorlevel 1 (
  call :fail "Python 3.12+ x64 is required."
  goto :done
)
py -3 -c "import tkinter; print('Tkinter: OK')"
if errorlevel 1 (
  call :fail "Tkinter is missing from Python. Reinstall Python with Tcl/Tk enabled."
  goto :done
)

call :step "[1/6] Installing build dependencies..."
py -3 -m pip install --upgrade Pillow openpyxl pyinstaller
if errorlevel 1 (
  call :fail "Python dependency installation failed."
  goto :done
)
py -3 -c "import PIL,openpyxl,PyInstaller; print('Build dependencies: OK')"
if errorlevel 1 (
  call :fail "Build dependencies could not be imported."
  goto :done
)

call :step "[2/6] Generating BDIX-IPTV application assets..."
py -3 build_brand_assets.py
if errorlevel 1 goto :buildfail
if not exist studio.ico goto :buildfail
if not exist Source\bdix_preview.png goto :buildfail

call :step "[3/6] Checking source..."
py -3 -m compileall -q Source
if errorlevel 1 goto :buildfail

call :step "[3b/6] Running startup smoke test (a Playlist Studio window opens for about 15 seconds - please do not click it)..."
py -3 tests\smoke_test.py
if errorlevel 1 (
  call :fail "Startup smoke test failed. Read the FAIL lines above. The EXE was NOT built."
  goto :done
)

call :step "[4/6] Downloading and verifying VLC 3.0.23..."
set "VLC_URL=https://download.videolan.org/pub/videolan/vlc/3.0.23/win64/vlc-3.0.23-win64.zip"
set "VLC_SHA256=992d19dbd0b8a7cde9167d2f7780b1ef6f92acc8a71acfa736101a21f35181e1"
if exist VLC.zip del /q VLC.zip
if exist VLC-TMP rmdir /s /q VLC-TMP
if exist VLC rmdir /s /q VLC
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%VLC_URL%' -OutFile '%~dp0VLC.zip'"
if errorlevel 1 goto :buildfail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash -Algorithm SHA256 '%~dp0VLC.zip').Hash.ToLower(); if($h -ne '%VLC_SHA256%'){Write-Host '[ERROR] VLC SHA-256 mismatch.' -ForegroundColor Red; exit 1}; Write-Host 'VLC SHA-256 verified.'"
if errorlevel 1 goto :buildfail
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0VLC.zip' -DestinationPath '%~dp0VLC-TMP' -Force"
if errorlevel 1 goto :buildfail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Get-ChildItem -LiteralPath '%~dp0VLC-TMP' -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'libvlc.dll') } | Select-Object -First 1; if(-not $d){exit 1}; New-Item -ItemType Directory -Force -Path '%~dp0VLC' | Out-Null; Get-ChildItem -LiteralPath $d.FullName | Copy-Item -Destination '%~dp0VLC' -Recurse -Force"
if errorlevel 1 goto :buildfail
if not exist VLC\libvlc.dll goto :buildfail
if not exist VLC\libvlccore.dll goto :buildfail
if not exist VLC\plugins goto :buildfail
rmdir /s /q VLC-TMP >nul 2>nul

call :step "[5/6] Building Playlist Studio 5.0..."
rem Close any previous Playlist Studio instance before replacing/packaging its EXE.
rem Windows keeps a running EXE locked, which prevents Compress-Archive from reading it.
taskkill /F /IM "Playlist-Studio-5.0.exe" >nul 2>nul
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Playlist-Studio-5.0.spec" del /q "Playlist-Studio-5.0.spec"
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name "Playlist-Studio-5.0" --icon "studio.ico" --add-data "VLC;VLC" --add-data "Source\bdix_preview.png;." --add-data "studio.ico;." Source\playlist_studio.py
if errorlevel 1 goto :buildfail
if not exist "dist\Playlist-Studio-5.0.exe" goto :buildfail
copy /y "dist\Playlist-Studio-5.0.exe" "%~dp0Playlist-Studio-5.0.exe" >nul
if errorlevel 1 goto :buildfail

call :step "[6/6] Packaging installer ZIP..."
rem Make absolutely sure the newly built executable is not held open by a previous run.
taskkill /F /IM "Playlist-Studio-5.0.exe" >nul 2>nul
if exist "Playlist-Studio-5.0-Setup.zip" del /q "Playlist-Studio-5.0-Setup.zip"
if exist "%~dp0Playlist-Studio-5.0.exe" powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $p='%~dp0Playlist-Studio-5.0.exe'; $s=[IO.File]::Open($p,'Open','Read','None'); $s.Close(); exit 0 } catch { Write-Host ('[ERROR] EXE is still locked: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
if errorlevel 1 goto :buildfail
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -LiteralPath '%~dp0Playlist-Studio-5.0.exe' -DestinationPath '%~dp0Playlist-Studio-5.0-Setup.zip' -CompressionLevel Optimal -Force"
if errorlevel 1 goto :buildfail
if not exist "Playlist-Studio-5.0-Setup.zip" goto :buildfail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$z=Get-Item '%~dp0Playlist-Studio-5.0-Setup.zip'; Add-Type -AssemblyName System.IO.Compression.FileSystem; $a=[IO.Compression.ZipFile]::OpenRead($z.FullName); try { if($a.Entries.Count -ne 1 -or $a.Entries[0].Name -ne 'Playlist-Studio-5.0.exe'){throw 'Installer ZIP must contain exactly one Playlist-Studio-5.0.exe entry.'} } finally {$a.Dispose()}; Write-Host 'Installer ZIP: exactly one EXE entry verified.'"
if errorlevel 1 goto :buildfail
for %%F in ("%~dp0Playlist-Studio-5.0.exe") do echo EXE: %%~zF bytes
for %%F in ("%~dp0Playlist-Studio-5.0-Setup.zip") do echo ZIP: %%~zF bytes

>>"%LOG%" echo Completed: %date% %time%
echo.
echo =================================
echo BUILD COMPLETE
echo =================================
echo EXE: %~dp0Playlist-Studio-5.0.exe
echo ZIP: %~dp0Playlist-Studio-5.0-Setup.zip
echo.
echo The build console will remain open.
pause
goto :done

:buildfail
call :fail "Build failed. The exact failing command is shown above."
goto :done

:step
echo %~1
>>"%LOG%" echo %~1
exit /b 0

:fail
echo.
echo [ERROR] %~1
>>"%LOG%" echo [ERROR] %~1
pause
exit /b 1

:done
endlocal
