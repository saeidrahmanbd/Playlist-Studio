"""Playlist Studio 5.0 — local Windows M3U editor."""
from __future__ import annotations
import multiprocessing
if __name__ == '__main__':
    multiprocessing.freeze_support()
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from tkinter import font as tkfont
from concurrent.futures import ThreadPoolExecutor
import pathlib, json, copy, threading, queue, urllib.request, urllib.parse, webbrowser, io, sys, re, os, time
from playlist_core import *
from studio_extras import PlayerPane,ScanWindow,show_info
from theme_manager import ThemeManager, THEMES
from desktop_support import FileDrops, editing_menu
import app_settings
from duplicates import DuplicatesWindow
from stream_support import evidence_key
from bdix_integration import XtreamConfig, xtream_login, xtream_m3u_url, audit_playlist, discover_new, import_candidates
try:
    from PIL import Image, ImageTk
except ImportError:Image=ImageTk=None

from fluent_ui import BG,PANEL,FIELD,INK,MUTED,ACCENT,LINE

class TextDialog(tk.Toplevel):
    def __init__(self,parent,title,initial,description=''):
        super().__init__(parent);self.result=None;self.title(title);self.configure(bg=PANEL);self.geometry('680x450');self.transient(parent)
        ttk.Label(self,text=description or title,wraplength=630).pack(anchor='w',padx=20,pady=(18,10))
        self.text=tk.Text(self,bg=FIELD,fg=INK,insertbackground=INK,wrap='word',font=('Consolas',11),relief='flat',undo=True)
        self.text.pack(fill='both',expand=True,padx=20);self.text.insert('1.0',initial)
        row=ttk.Frame(self);row.pack(fill='x',padx=20,pady=16)
        ttk.Button(row,text='Cancel',command=self.destroy).pack(side='right');ttk.Button(row,text='Apply',style='Accent.TButton',command=self.accept).pack(side='right',padx=8)
        self.bind('<Escape>',lambda e:self.destroy());self.grab_set();self.text.focus_set();parent.wait_window(self)
    def accept(self):self.result=self.text.get('1.0','end-1c');self.destroy()

class ChoiceDialog(tk.Toplevel):
    def __init__(self,parent,title,label,values,initial=None):
        super().__init__(parent);self.result=None;self.title(title);self.configure(bg=PANEL);self.resizable(False,False);self.transient(parent)
        ttk.Label(self,text=label,wraplength=420).pack(anchor='w',padx=20,pady=(20,12));self.var=tk.StringVar(value=initial or (values[0] if values else ''))
        self.combo=ttk.Combobox(self,textvariable=self.var,values=values,state='readonly',width=48);self.combo.pack(padx=20,pady=8)
        row=ttk.Frame(self);row.pack(fill='x',padx=20,pady=20);ttk.Button(row,text='Cancel',command=self.destroy).pack(side='right');ttk.Button(row,text='Continue',style='Accent.TButton',command=self.accept).pack(side='right',padx=8)
        self.bind('<Return>',lambda e:self.accept());self.bind('<Escape>',lambda e:self.destroy());self.update_idletasks();parent.update_idletasks();dw,dh=self.winfo_width(),self.winfo_height();px,py=parent.winfo_rootx(),parent.winfo_rooty();pw,ph=parent.winfo_width(),parent.winfo_height();self.geometry(f'{dw}x{dh}+{px+max(0,(pw-dw)//2)}+{py+max(0,(ph-dh)//2)}');self.grab_set();self.combo.focus_set();parent.wait_window(self)
    def accept(self):self.result=self.var.get();self.destroy()

class Studio(tk.Tk):
    def __init__(self):
        import gc
        gc.collect()  # Dispose prior Tk instances on the UI thread.
        super().__init__();self.prefs=app_settings.load();self.prefs['reopen_last']=False;app_settings.update(reopen_last=False);self.sort_state=None;self.autosave_job=None;self._pane_pref=self._load_pane_pref();self.title('Playlist Studio 5.0');width=min(1480,self.winfo_screenwidth()-70);height=min(1000,self.winfo_screenheight()-80);self.geometry(f'{width}x{height}+{max(0,(self.winfo_screenwidth()-width)//2)}+{max(0,(self.winfo_screenheight()-height)//2-20)}');self.minsize(1080,720);self.configure(bg=BG);self.restore_window()
        self.doc=Playlist();self.history=History();self.path=None;self.saved=self.doc.fingerprint();self.current=None;self.active_group=None;self.active_groups=[];self.category_scroll={};self.form_dirty=False;self.loading=False;self.rendering=False;self.events=queue.Queue();self.preview_token=0;self.drag=None;self.filter_job=None;self.display_query='';self.last_scan_report=None
        self.scan_results={};self.health_view=tk.StringVar(value='All channels');self.file_drops=None;self.player=None;self.scan_windows=[];self.drag_badge=None;self.drop_target=None;self.drag_ids=[]
        self.logo_cache={};self.logo_job=None;self.logo_future=None;self.xtream_cfg=None;self.logo_pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='Logo')
        icon=pathlib.Path(getattr(sys,'_MEIPASS',pathlib.Path(__file__).parent))/'studio.ico'
        if icon.exists():self.iconbitmap(str(icon))
        self.theme_manager=ThemeManager(self);self.setup_style();self.build();self.bind_keys()
        self.bind_all('<Button-3>',editing_menu,add='+')
        self._startup_stage='ui-built'
        self._startup_log('UI constructed; deferring theme/playlist initialization to Tk event loop.')
        self.protocol('WM_DELETE_WINDOW',self.close_app)
        self.after_idle(self._finish_startup)

    def _startup_log(self,message):
        try:
            path=pathlib.Path(os.environ.get('TEMP') or pathlib.Path.home())/'Playlist Studio 5.0-startup.log'
            mode='w' if path.exists() and path.stat().st_size>200_000 else 'a'
            with path.open(mode,encoding='utf-8') as f:
                f.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {message}\n')
        except Exception:
            pass

    def _finish_startup(self):
        if getattr(self,'_startup_finished',False):
            return
        self._startup_stage='theme'
        self._startup_log('Applying selected theme: '+self.theme_manager.name)
        try:
            self.theme_manager.apply(self.theme_manager.name,persist=False)
            self._startup_log('Theme applied.')
            self._startup_stage='refresh'
            self.refresh()
            self._startup_log('Initial playlist refresh completed.')
            self._startup_stage='runtime'
            self.after(100,self.poll)
            self.file_drops=FileDrops(self)
            self.bind('<Destroy>',lambda e:self.file_drops.close() if e.widget is self else None,add='+')
            self._startup_finished=True
            self._startup_stage='ready'
            self._startup_log('Startup complete; event loop ready.')
            self.after(250,self._post_startup)
            if len(sys.argv)>1 and pathlib.Path(sys.argv[1]).is_file():
                def startup():
                    self._startup_log('Opening command-line playlist.')
                    self.open_paths([sys.argv[1]],'Replace current playlist')
                    if '--play' in sys.argv[2:] and self.doc.channels:
                        self.table.selection_set(self.doc.ordered()[0].id);self.select_channel();self.play_selected()
                self.after(120,startup)
        except Exception as ex:
            self._startup_log(f'STARTUP ERROR at {self._startup_stage}: {type(ex).__name__}: {ex}')
            raise

    def _post_startup(self):
        # Startup intentionally opens with a blank playlist.
        # Crash recovery and an explicitly supplied command-line playlist remain supported.
        try:
            self.check_recovery()
        except Exception as ex:
            self._startup_log(f'Recovery check failed: {type(ex).__name__}: {ex}')
        self.autosave_job=self.after(60000,self.autosave)

    # ---- window / preference persistence --------------------------------
    def _load_pane_pref(self):
        try:
            panes=self.prefs.get('panes')
            return (int(panes['left']),int(panes['right'])) if isinstance(panes,dict) else None
        except Exception:return None
    def restore_window(self):
        self._normal_geo=None
        geo=self.prefs.get('window')
        try:
            if isinstance(geo,dict):
                sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
                w=max(1080,min(int(geo['w']),sw));h=max(720,min(int(geo['h']),sh))
                x=max(0,min(int(geo['x']),sw-w));y=max(0,min(int(geo['y']),sh-120))
                self.geometry(f'{w}x{h}+{x}+{y}')
                if geo.get('zoomed'):self.after(50,lambda:self.state('zoomed'))
        except Exception:pass
        self.bind('<Configure>',self._track_geometry,add='+')
    def _track_geometry(self,event):
        if event.widget is not self:return
        try:
            if self.state()!='normal':return
            m=re.match(r'(\d+)x(\d+)([+-]+\d+)([+-]+\d+)',self.geometry())
            if m:self._normal_geo=tuple(int(g.replace('+','')) for g in m.groups())
        except Exception:pass
    def set_pref(self,key,value):
        self.prefs[key]=value;app_settings.update(**{key:value})
    def save_prefs(self):
        values={}
        try:
            geo=self._normal_geo
            if geo:values['window']={'w':geo[0],'h':geo[1],'x':geo[2],'y':geo[3],'zoomed':self.state()=='zoomed'}
            if self._pane_pref:values['panes']={'left':self._pane_pref[0],'right':self._pane_pref[1]}
            if self.player:values['volume']=round(float(self.player.volume.get()))
        except Exception:pass
        if values:app_settings.update(**values)
    def remember_playlist(self,path):
        self.prefs['last_playlist']=str(path);app_settings.update(last_playlist=str(path))
    def open_backups_folder(self):
        folder=app_settings.backup_dir()
        try:folder.mkdir(parents=True,exist_ok=True)
        except OSError:pass
        try:os.startfile(str(folder))
        except AttributeError:webbrowser.open(folder.as_uri())
        except OSError as ex:self.error(ex)

    # ---- autosave / recovery ---------------------------------------------
    def autosave(self):
        try:
            if self.doc.fingerprint()!=self.saved:
                app_settings.write_recovery(serialize(self.doc),{'path':self.path or '','name':self.doc.name,'channels':len(self.doc.channels),'time':time.strftime('%H:%M:%S on %d %b %Y')})
            else:app_settings.clear_recovery()
        except Exception:pass
        finally:
            try:self.autosave_job=self.after(60000,self.autosave)
            except Exception:pass
    def check_recovery(self):
        found=app_settings.read_recovery()
        if not found:return False
        text,meta=found
        name=meta.get('name') or 'playlist'
        if not messagebox.askyesno('Recover unsaved work',f'Playlist Studio did not close normally last time.\n\nRecover “{name}” ({meta.get("channels","?")} channels, autosaved {meta.get("time","earlier")})?',parent=self):
            app_settings.clear_recovery();return False
        try:doc,_=parse(text,name)
        except Exception as ex:
            self.error(ex);app_settings.clear_recovery();return False
        self.doc=doc;self.path=meta.get('path') or None;self.current=None;self.active_group=None;self.active_groups=[];self.history=History();self.saved='';self.health_view.set('All channels');self.scan_results.clear();self.last_scan_report=None
        self.refresh();self.status.set('Recovered unsaved work from autosave. Use Save to keep it.')
        return True
    def backup_before_save(self,path):
        try:app_settings.backup_file(path)
        except Exception:pass

    def find_duplicates(self):
        if not self.doc.channels:self.error('Open a playlist before looking for duplicates.');return
        window=getattr(self,'dup_window',None)
        if window is not None and window.winfo_exists():window.lift();window.refresh();return
        self.dup_window=DuplicatesWindow(self)

    # ---- sortable columns ---------------------------------------------------
    SORT_LABELS={'name':'Channel','group':'Group','health':'Status','url':'Stream URL'}
    SORT_INDEX={'name':0,'group':1,'health':2,'url':3}
    def sort_by(self,key):
        cur=self.sort_state
        self.sort_state=(key,False) if cur is None or cur[0]!=key else (key,True) if not cur[1] else None
        self.update_headings();self.refresh_table()
    def update_headings(self):
        for key,label in self.SORT_LABELS.items():
            arrow=' ▲' if self.sort_state==(key,False) else ' ▼' if self.sort_state==(key,True) else ''
            self.table.heading(key,text=label+arrow)
    def sorted_rows(self,rows):
        if not self.sort_state:return rows
        key,reverse=self.sort_state;idx=self.SORT_INDEX[key]
        def natural(text):return [int(t) if t.isdigit() else t.casefold() for t in re.split(r'(\d+)',text or '')]
        return sorted(rows,key=lambda r:natural(r[1] if key=='health' else r[3][idx]),reverse=reverse)

    def setup_style(self):
        tkfont.nametofont('TkDefaultFont').configure(family='Segoe UI',size=10);self.option_add('*TCombobox*Listbox.background',FIELD);self.option_add('*TCombobox*Listbox.foreground',INK)
        s=ttk.Style(self);s.theme_use('clam');s.configure('.',background=PANEL,foreground=INK,font=('Segoe UI',10));s.configure('TFrame',background=PANEL);s.configure('Shell.TFrame',background=BG)
        s.configure('TLabel',background=PANEL,foreground=INK);s.configure('Muted.TLabel',foreground=MUTED);s.configure('Title.TLabel',font=('Segoe UI Semibold',17),foreground=INK);s.configure('Section.TLabel',font=('Segoe UI Semibold',11))
        s.configure('TButton',background=LINE,foreground=INK,borderwidth=0,padding=(10,7));s.map('TButton',background=[('active','#394b66'),('disabled',PANEL)],foreground=[('disabled','#596980')])
        s.configure('Accent.TButton',background=ACCENT,foreground='#0d2330',font=('Segoe UI Semibold',10));s.map('Accent.TButton',background=[('active','#83e1ee')])
        s.configure('TEntry',fieldbackground=FIELD,foreground=INK,insertcolor=INK,bordercolor=LINE,padding=7);s.configure('TCombobox',fieldbackground=FIELD,foreground=INK,arrowcolor=INK,padding=6);s.map('TCombobox',fieldbackground=[('readonly',FIELD)],foreground=[('readonly',INK)],selectbackground=[('readonly',FIELD)],selectforeground=[('readonly',INK)])
        s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=INK,rowheight=31,borderwidth=0,font=('Segoe UI',10));s.map('Treeview',background=[('selected','#214e65')],foreground=[('selected','#ffffff')]);s.configure('Treeview.Heading',background=LINE,foreground=MUTED,padding=(8,8),font=('Segoe UI Semibold',10));s.map('Treeview.Heading',background=[('active','#35475f')]);s.configure('TSeparator',background=LINE)
        s.configure('TPanedwindow',background=BG);s.configure('Vertical.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,borderwidth=0)
        for name in ('Treeview','Treeview.Heading','TEntry','TCombobox','Vertical.TScrollbar'):s.configure(name,bordercolor=LINE,lightcolor=LINE,darkcolor=LINE)
        s.configure('TNotebook',background=PANEL,borderwidth=0,bordercolor=LINE,lightcolor=LINE,darkcolor=LINE);s.configure('TNotebook.Tab',background=FIELD,foreground=MUTED,padding=(18,10),font=('Segoe UI Semibold',10),bordercolor=LINE,lightcolor=LINE,darkcolor=LINE);s.map('TNotebook.Tab',background=[('selected',LINE)],foreground=[('selected',ACCENT)])
        s.configure('Horizontal.TProgressbar',background=ACCENT,troughcolor=FIELD,borderwidth=0);s.configure('Horizontal.TScale',background=LINE,troughcolor=FIELD,bordercolor=LINE,lightcolor=LINE,darkcolor=LINE);s.configure('Horizontal.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,bordercolor=LINE,lightcolor=LINE,darkcolor=LINE)

    def build(self):
        from fluent_ui import build
        from row_logos import RowLogos
        build(self)
        self.row_logos=RowLogos(self)

    def textbox(self,parent,height):
        w=tk.Text(parent,height=height,bg=FIELD,fg=INK,insertbackground=INK,font=('Consolas',10),wrap='word',relief='flat',padx=8,pady=7,undo=True);w.pack(fill='x');return w
    def bind_keys(self):
        for seq,cmd in [('<Control-o>',self.open_files),('<Control-s>',self.save),('<Control-Shift-S>',lambda:self.save(True)),('<Control-z>',self.undo),('<Control-y>',self.redo),('<Control-f>',lambda:self.focus_search())]:self.bind(seq,lambda e,f=cmd:(f(),'break')[1])
    def focus_search(self):
        # Locate the search entry by its variable rather than relying on widget order.
        def visit(w):
            for c in w.winfo_children():
                if isinstance(c,ttk.Entry) and str(c.cget('textvariable'))==str(self.search):c.focus_set();c.selection_range(0,'end');return True
                if visit(c):return True
        visit(self)
    def error(self,ex):messagebox.showerror('Playlist Studio',str(ex),parent=self)
    def field_changed(self):
        if not self.loading:self.form_dirty=True;self.apply_button.configure(text='Apply changes •');self.update_title()
    def text_changed(self,e):
        if e.widget.edit_modified():self.field_changed();e.widget.edit_modified(False)
    def update_title(self):
        dirty=self.form_dirty or self.doc.fingerprint()!=self.saved;self.title(('● ' if dirty else '')+self.doc.name+' — Playlist Studio 5.0')
        self.undo_button.configure(state='normal' if self.history.past else 'disabled');self.redo_button.configure(state='normal' if self.history.future else 'disabled')
    def commit(self,fn,summary):
        before=self.doc.snapshot()
        try:fn()
        except Exception as ex:self.doc=before;self.error(ex);return False
        if before.fingerprint()!=self.doc.fingerprint():self.history.record(before)
        self.refresh();self.status.set(summary);return True
    def refresh(self,select=None):
        self.rendering=True
        try:
            self.groups.delete(*self.groups.get_children());self.groups.insert('','end',iid='ALL',text=f'All channels   {len(self.doc.channels):,}')
            count={c.id:0 for c in self.doc.categories}
            for ch in self.doc.channels:count[ch.category_id]=count.get(ch.category_id,0)+1
            for cat in self.doc.categories:self.groups.insert('','end',iid=cat.id,text=f'{cat.name}   {count[cat.id]:,}')
            valid=[g for g in self.active_groups if g in count] if self.active_groups else ([self.active_group] if self.active_group in count else [])
            self.active_groups=valid;self.active_group=valid[0] if valid else None
            self.groups.selection_set(valid or 'ALL');self.category_combo.configure(values=[c.name for c in self.doc.categories]);self.refresh_table(select)
            self.update_title()
        finally:self.rendering=False
    def refresh_table(self,select=None):
        was=self.rendering;self.rendering=True
        selected=list(select if select is not None else self.table.selection());self.table.delete(*self.table.get_children());query=self.search.get().casefold().strip();shown=0
        visible_channels=[];rows=[]
        for ch in self.doc.ordered():
            if self.active_groups and ch.category_id not in self.active_groups:continue
            if not self.active_groups and self.active_group and ch.category_id!=self.active_group:continue
            result=self.scan_results.get(ch.id)
            if result is not None and evidence_key(ch)!=result.key:result=None
            health=self.health_view.get()
            if health=='Dead links only' and (result is None or result.status!='Dead'):continue
            if health=='Needs review' and (result is None or result.status in ('Dead','Responsive')):continue
            if health=='Not scanned' and result is not None:continue
            hay=' '.join([ch.name,ch.url,self.doc.category(ch.category_id).name]+list(ch.attrs.values())).casefold()
            if query and query not in hay:continue
            ext=urllib.parse.urlsplit(ch.url.split('|')[0]).path.lower() if ch.url else ''
            fmt='Missing' if not ch.url else 'DASH' if ext.endswith('.mpd') else 'HLS' if ext.endswith(('.m3u8','.m3u')) else 'Video' if ext.endswith(('.mp4','.mkv')) else 'Stream'
            status=result.status if result else 'Not scanned'
            tags=[]
            if not ch.url:tags.append('missing')
            elif status=='Dead':tags.append('dead')
            elif status not in ('Responsive','Not scanned'):tags.append('review')
            label=('● ' if result else '○ ')+status
            rows.append((ch,status,tags,(ch.name,self.doc.category(ch.category_id).name,label,ch.url,ch.attrs.get('tvg-id',''),fmt)))
        for ch,status,tags,values in self.sorted_rows(rows):
            self.table.insert('','end',iid=ch.id,text='▶',values=values,tags=tuple((['alternate'] if shown%2 else [])+tags));shown+=1;visible_channels.append(ch)
        cols=('name','health','url') if len(self.active_groups)==1 else ('name','group','health','url')
        if tuple(self.table['displaycolumns'])!=cols:self.table.configure(displaycolumns=cols)
        self.row_logos.set_rows(visible_channels)
        self.update_scan_summary()
        key=tuple(self.active_groups) if self.active_groups else ('ALL',)
        if key in self.category_scroll:
            try:self.table.yview_moveto(self.category_scroll[key])
            except Exception:pass
        valid=[i for i in selected if self.table.exists(i)]
        if valid:self.table.selection_set(valid);self.table.see(valid[0])
        heading=self.doc.category(self.active_groups[0]).name if len(self.active_groups)==1 else (f'{len(self.active_groups)} categories selected' if self.active_groups else 'All channels')
        self.group_heading.configure(text=heading);self.empty.configure(text=f'{shown:,} shown · Select a channel to edit. Ctrl-click or Shift-click for bulk actions.' if shown else 'No matches. Change View, clear search, or run Scan links.' if self.doc.channels else 'Open an M3U file or import a playlist link to start.')
        self.display_query=self.search.get();self.rendering=was
        if self.current and any(ch.id==self.current for ch in self.doc.channels):
            if not self.form_dirty:self.load_form(self.doc.channel(self.current))
        else:self.current=None;self.load_form(None)
    def update_scan_summary(self):
        results=[r for c in self.doc.channels if (r:=self.scan_results.get(c.id)) is not None and r.key==evidence_key(c)]
        dead=sum(r.status=='Dead' for r in results);responsive=sum(r.status=='Responsive' for r in results)
        self.health_summary.configure(text=f'{responsive} responsive  ·  {dead} dead  ·  {len(results)-dead-responsive} review' if results else 'No scan yet')
        self.export_button.configure(state='normal' if self.last_scan_report and self.last_scan_report['results'] else 'disabled')
    def search_changed(self,*_):
        if self.filter_job:self.after_cancel(self.filter_job)
        def run():
            self.filter_job=None
            if not self.resolve_form():self.search.set(self.display_query);return
            self.refresh_table()
        self.filter_job=self.after(180,run)
    def resolve_form(self):
        if not self.form_dirty or not self.current:return True
        choice=messagebox.askyesnocancel('Unapplied channel edits','Apply the changes to this channel before continuing?\n\nYes = apply · No = discard · Cancel = stay here',parent=self)
        if choice is None:return False
        if choice:return self.apply_channel()
        self.form_dirty=False;self.load_form(self.doc.channel(self.current));return True
    def select_group(self,event=None):
        if self.rendering:return
        sel=list(self.groups.selection())
        if not sel:return
        if 'ALL' in sel:
            sel=[]
            # Only rewrite the selection when it actually differs. ttk emits
            # <<TreeviewSelect>> even for an identical selection_set(), which
            # re-entered select_group forever and froze the UI at startup.
            if list(self.groups.selection())!=['ALL']:
                self.rendering=True
                try:self.groups.selection_set('ALL')
                finally:self.after_idle(lambda:setattr(self,'rendering',False))
        oldkey=tuple(self.active_groups) if self.active_groups else ('ALL',)
        try:self.category_scroll[oldkey]=self.table.yview()[0]
        except Exception:pass
        if not self.resolve_form():
            self.rendering=True;self.groups.selection_set(self.active_groups or 'ALL');self.rendering=False;return
        self.active_groups=sel
        self.active_group=sel[0] if sel else None
        self.refresh_table()
    def select_channel(self,event=None):
        if self.rendering:return
        ids=self.table.selection();new=ids[0] if len(ids)==1 else None
        if new==self.current:return
        if not self.resolve_form():
            self.rendering=True
            if self.current and self.table.exists(self.current):self.table.selection_set(self.current)
            self.rendering=False;return
        self.current=new;self.table.selection_set([i for i in ids if self.table.exists(i)]);self.load_form(self.doc.channel(new) if new else None);self.selection_label.configure(text=f'{len(ids)} selected — use Move to or Delete.' if len(ids)>1 else 'Edit metadata, then apply.' if new else 'Select one channel to edit.')
    def load_form(self,ch):
        if self.logo_job:self.after_cancel(self.logo_job);self.logo_job=None
        if self.logo_future:self.logo_future.cancel()
        self.loading=True;self.preview_token+=1;self.logo_label.configure(image='',text='TV',width=5,height=2);self.logo_image=None
        for widget in self.widgets:widget.configure(state='readonly' if ch and widget==self.category_combo else 'normal' if ch else 'disabled')
        for k,v in self.fields.items():v.set(ch.name if ch and k=='name' else ch.duration if ch and k=='duration' else self.doc.category(ch.category_id).name if ch and k=='category' else ch.attrs.get(k,'') if ch else '')
        for w,value in [(self.stream,ch.url if ch else ''),(self.directives,'\n'.join(ch.directives) if ch else '')]:w.configure(state='normal');w.delete('1.0','end');w.insert('1.0',value);w.edit_modified(False);w.edit_reset();w.configure(state='normal' if ch else 'disabled')
        count=len(self.table.selection());self.selection_label.configure(text=f'{count} selected — use Move to or Delete.' if count>1 else 'Edit metadata, then apply.' if ch else 'Select one channel to edit.')
        self.advanced={k:v for k,v in ch.attrs.items() if k not in set(self.fields)-{'name','category','duration'} and k!='group-title'} if ch else {};self.form_dirty=False;self.apply_button.configure(text='Apply changes',state='normal' if ch else 'disabled');self.loading=False
        self.logo_status.configure(text='Loading logo…' if ch and ch.attrs.get('tvg-logo','').strip() else 'No logo set.' if ch else 'Select a channel to see its logo.')
        if ch and ch.attrs.get('tvg-logo','').strip():self.logo_job=self.after(150,self.logo_preview)
    def apply_channel(self):
        if not self.current:return True
        try:
            c=self.doc.channel(self.current);name=single(self.fields['name'].get().strip(),'Name')
            if not name:raise PlaylistError('Enter a channel name.')
            url=single(self.stream.get('1.0','end-1c').strip(),'Stream URL');cat=next((x for x in self.doc.categories if x.name==self.fields['category'].get()),None)
            if not cat:raise PlaylistError('Choose a category.')
            attrs=dict(self.advanced)
            for k,v in self.fields.items():
                if k not in ('name','category','duration') and v.get():single(v.get(),k);quote(v.get());attrs[k]=v.get()
            duration=self.fields['duration'].get().strip()
            if not re.fullmatch(r'-?\d+(?:\.\d+)?',duration):raise PlaylistError('Duration must be a number. Use -1 for a live channel.')
            if attrs.get('tvg-name')==c.name and name!=c.name:attrs['tvg-name']=name
            directives=[x.strip() for x in self.directives.get('1.0','end-1c').splitlines() if x.strip()]
            if any(not x.startswith('#') or x.startswith(('#EXTINF','#EXTM3U')) for x in directives):raise PlaylistError('Playback directives must start with # and cannot contain new channels.')
            before=self.doc.snapshot();c.name=name;c.url=url;c.attrs=attrs;c.directives=directives;c.category_id=cat.id;c.duration=duration
            if before.fingerprint()!=self.doc.fingerprint():self.history.record(before)
            self.form_dirty=False;self.refresh(select=[c.id]);self.status.set(f'Saved changes to {name}.');return True
        except Exception as ex:self.error(ex);return False
    def revert_form(self):
        if self.current:self.load_form(self.doc.channel(self.current));self.update_title()
    def edit_attributes(self):
        if not self.current:return
        d=TextDialog(self,'Additional M3U attributes',json.dumps(self.advanced,ensure_ascii=False,indent=2),'Extra attributes are preserved. Enter a JSON object of attribute names and text values.')
        if d.result is None:return
        try:
            data=json.loads(d.result)
            if not isinstance(data,dict) or any(not isinstance(k,str) or not re.fullmatch(r'[\w-]+',k) or not isinstance(v,str) for k,v in data.items()):raise PlaylistError('Use an object with valid attribute names and text values.')
            if any(k in set(self.fields)-{'name','category','duration'} or k=='group-title' for k in data):raise PlaylistError('Edit common fields in the channel form, not in Additional attributes.')
            for v in data.values():quote(v)
            self.advanced=data;self.field_changed()
        except Exception as ex:self.error(ex)
    def select_all_visible(self):
        ids=self.table.get_children('')
        if ids:
            self.table.selection_set(ids); self.table.focus(ids[0]); self.table.see(ids[0]); self.status.set(f'Selected {len(ids)} channel(s) in current category.')
        return 'break'

    def selected_ids(self):return list(self.table.selection())
    def add_category(self):
        if not self.resolve_form():return
        name=simpledialog.askstring('Add category','Category name:',parent=self)
        if name is None:return
        def change():
            if not name.strip():raise PlaylistError('Enter a category name.')
            if any(c.name==name.strip() for c in self.doc.categories):raise PlaylistError('This category already exists.')
            self.active_group=self.doc.ensure_category(name)
        self.commit(change,'Category added.')
    def _single_category(self,action):
        if len(self.active_groups)>1:
            self.status.set(f'Select a single category to {action}.');return False
        return bool(self.active_group)
    def rename_category(self):
        if not self._single_category('rename') or not self.resolve_form():return
        cid=self.active_group;name=simpledialog.askstring('Rename category','New name:',initialvalue=self.doc.category(cid).name,parent=self)
        if name is not None:self.commit(lambda:self.doc.rename_category(cid,name),'Category renamed.')
    def delete_category(self):
        cids=list(self.active_groups) or ([self.active_group] if self.active_group else [])
        if not cids or not self.resolve_form():return
        cats=[self.doc.category(c) for c in cids];doomed=set(cids);count=sum(c.category_id in doomed for c in self.doc.channels)
        many=len(cids)>1
        choices=[f'Move their channels to Uncategorized' if many else 'Move its channels to Uncategorized',f'Delete the categories and their channels' if many else 'Delete category and its channels'] if count else ['Delete empty categories' if many else 'Delete empty category']
        message=f'{len(cids)} categories contain {count} channels in total. What should happen?' if many else f'“{cats[0].name}” contains {count} channels. What should happen?'
        d=ChoiceDialog(self,'Delete categories' if many else 'Delete category',message,choices)
        if not d.result:return
        def change():
            if d.result.startswith('Move'):
                if any(c.name=='Uncategorized' for c in cats):raise PlaylistError('Move these channels to another category first, or choose to delete them.')
                target=self.doc.ensure_category('Uncategorized')
                for ch in self.doc.channels:
                    if ch.category_id in doomed:ch.category_id=target
            else:self.doc.channels=[ch for ch in self.doc.channels if ch.category_id not in doomed]
            self.doc.categories=[c for c in self.doc.categories if c.id not in doomed];self.active_group=None;self.active_groups=[]
        self.commit(change,f'{len(cids)} categories removed. Undo is available.' if many else 'Category removed. Undo is available.')
    def move_category(self,step):
        if not self._single_category('move') or not self.resolve_form():return
        def change():
            i=next(i for i,c in enumerate(self.doc.categories) if c.id==self.active_group);j=i+step
            if 0<=j<len(self.doc.categories):self.doc.categories[i],self.doc.categories[j]=self.doc.categories[j],self.doc.categories[i]
        self.commit(change,'Category order updated.')
    def sort_categories(self):
        if self.resolve_form():self.commit(lambda:self.doc.categories.sort(key=lambda c:c.name.casefold()),'Categories sorted A–Z.')
    def add_channel(self):
        if not self.resolve_form():return
        def change():
            cat=self.active_group or self.doc.ensure_category('Uncategorized');ch=Channel('New channel','',cat,{'tvg-name':'New channel'});self.doc.channels.append(ch);self.current=ch.id;self.active_group=cat;self.search.set('')
        if self.commit(change,'New channel added. Fill in its name and stream URL.'):self.refresh(select=[self.current]);self.load_form(self.doc.channel(self.current))
    def duplicate(self):
        ids=self.selected_ids()
        if not ids or not self.resolve_form():return
        def change():
            for cid in ids:
                old=self.doc.channel(cid);ch=copy.deepcopy(old);ch.id=uid();ch.name+=' (Copy)';ch.attrs['tvg-name']=ch.name;i=self.doc.channels.index(old);self.doc.channels.insert(i+1,ch)
        self.commit(change,f'Duplicated {len(ids)} channel(s).')
    def delete_channels(self):
        ids=self.selected_ids()
        if not ids or not self.resolve_form():return
        if not messagebox.askyesno('Delete channels',f'Delete {len(ids)} selected channel(s)? You can undo this.',parent=self):return
        self.commit(lambda:setattr(self.doc,'channels',[c for c in self.doc.channels if c.id not in ids]),f'Deleted {len(ids)} channel(s).')
    def move_selected(self):
        ids=self.selected_ids()
        if not ids or not self.resolve_form():return
        d=ChoiceDialog(self,'Move channels',f'Move {len(ids)} channel(s) to:',[c.name for c in self.doc.categories])
        if d.result:
            target=next(c.id for c in self.doc.categories if c.name==d.result);self.commit(lambda:self.doc.move_channels(ids,target),f'Moved {len(ids)} channel(s) to {d.result}.')
    def move_rows(self,step):
        ids=self.selected_ids()
        if not ids or not self.resolve_form():return
        if self.sort_state:self.error('Clear the column sort before reordering channels: click the sorted column header until its arrow disappears.');return
        if self.search.get().strip():self.error('Clear search before reordering channels. Move to a category still works while filtering.');return
        cats={self.doc.channel(i).category_id for i in ids}
        if len(cats)!=1:self.error('Select channels from one category to reorder them.');return
        cat=cats.pop()
        def change():
            group=[c for c in self.doc.channels if c.category_id==cat];indices=range(len(group)) if step<0 else range(len(group)-1,-1,-1)
            for i in indices:
                j=i+step
                if group[i].id in ids and 0<=j<len(group) and group[j].id not in ids:group[i],group[j]=group[j],group[i]
            it=iter(group);self.doc.channels=[next(it) if c.category_id==cat else c for c in self.doc.channels]
        self.commit(change,'Channel order updated.');self.refresh(select=ids)
    def sort_channels(self):
        if not self.resolve_form():return
        def change():
            # Keep naturally numbered Backups immediately after their main channel.
            def key(c):
                m=re.search(r'\s*[\[(]Backup\s+(\d+)[\])]$',c.name,re.I)
                return ((c.name[:m.start()] if m else c.name).casefold(),int(m.group(1)) if m else 0)
            for cat in self.doc.categories:
                if self.active_group and cat.id!=self.active_group:continue
                vals=sorted([c for c in self.doc.channels if c.category_id==cat.id],key=key);it=iter(vals);self.doc.channels=[next(it) if c.category_id==cat.id else c for c in self.doc.channels]
        self.commit(change,'Channels sorted A–Z. Numbered backups stay with the main channel.')
    def drag_start(self,e,kind):
        self.clear_drag()
        row=e.widget.identify_row(e.y);self.drag=(kind,row,e.x_root,e.y_root) if row and row!='ALL' else None
        self.drag_ids=list(self.table.selection()) if kind=='channel' and row in self.table.selection() else [row]
        if kind=='channel' and len(self.drag_ids)>1 and not e.state&5:return 'break'
    def channel_press(self,event):
        row=self.table.identify_row(event.y)
        if row and self.table.identify_column(event.x)=='#0':
            if not self.resolve_form():return 'break'
            self.clear_drag();self.table.selection_set(row);self.select_channel();self.play_selected();return 'break'
        return self.drag_start(event,'channel')
    def channel_hover(self,event):
        if self.drag:return
        self.table.configure(cursor='hand2' if self.table.identify_row(event.y) and self.table.identify_column(event.x)=='#0' else '')
    def clear_drop(self):
        if self.drop_target:
            widget,row,tags=self.drop_target
            if widget.winfo_exists() and widget.exists(row):widget.item(row,tags=tags)
        self.drop_target=None
    def clear_drag(self):
        self.clear_drop();self.drag=None;self.configure(cursor='')
        if self.drag_badge:self.drag_badge.destroy();self.drag_badge=None
    def drag_motion(self,e):
        if not self.drag:return
        kind,row,x,y=self.drag
        if abs(x-e.x_root)+abs(y-e.y_root)<12:return
        self.clear_drop();target=self.winfo_containing(e.x_root,e.y_root);targetrow=target.identify_row(e.y_root-target.winfo_rooty()) if target in (self.groups,self.table) else ''
        valid=bool(targetrow and targetrow!='ALL' and ((kind=='channel' and (target==self.groups or not self.search.get().strip()) and targetrow not in self.drag_ids) or (kind=='category' and target==self.groups and targetrow!=row)))
        if valid:
            self.drop_target=(target,targetrow,target.item(targetrow,'tags'));target.item(targetrow,tags=tuple(target.item(targetrow,'tags'))+('drop',))
            name=self.doc.category(targetrow).name if target==self.groups else self.doc.channel(targetrow).name
            label=(f'Move {len(self.drag_ids)} channel(s) → ' if kind=='channel' and target==self.groups else 'Place before → ')+name
            localy=e.y_root-target.winfo_rooty()
            if localy<22:target.yview_scroll(-1,'units')
            elif localy>target.winfo_height()-22:target.yview_scroll(1,'units')
        else:label=f'{len(self.drag_ids)} channel(s) · drop onto a category' if kind=='channel' else 'Drag onto another category'
        if not self.drag_badge:self.drag_badge=tk.Label(self,font=('Segoe UI Semibold',10),padx=14,pady=9,relief='solid',borderwidth=1)
        self.drag_badge.configure(text=label,bg=ACCENT if valid else LINE,fg=FIELD if valid else INK);self.drag_badge.place(x=min(e.x_root-self.winfo_rootx()+16,max(0,self.winfo_width()-370)),y=min(e.y_root-self.winfo_rooty()+20,self.winfo_height()-45));self.drag_badge.lift();self.configure(cursor='hand2' if valid else 'X_cursor');return 'break'
    def drag_end(self,e):
        if not self.drag:return
        kind,row,x,y=self.drag;ids=list(self.drag_ids);self.clear_drag()
        if abs(x-e.x_root)+abs(y-e.y_root)<12:return
        target=self.winfo_containing(e.x_root,e.y_root)
        if target not in (self.groups,self.table) or not self.resolve_form():return
        targetrow=target.identify_row(e.y_root-target.winfo_rooty())
        if kind=='category' and target==self.groups and targetrow and targetrow!='ALL' and targetrow!=row:
            def change():
                item=self.doc.category(row);self.doc.categories.remove(item);i=next(i for i,c in enumerate(self.doc.categories) if c.id==targetrow);self.doc.categories.insert(i,item)
            self.commit(change,'Category moved.');return
        if kind=='channel':
            if target==self.groups and targetrow and targetrow!='ALL':self.commit(lambda:self.doc.move_channels(ids,targetrow),'Channels moved to category.')
            elif target==self.table and targetrow and not self.search.get().strip():self.commit(lambda:self.doc.move_channels(ids,self.doc.channel(targetrow).category_id,targetrow),'Channels reordered.')
    def play_selected(self):
        ids=self.selected_ids()
        if len(ids)!=1:self.error('Select one channel to play.');return
        if not self.resolve_form():return
        if self.player is None:
            self.player=PlayerPane(self.player_host,self,compact=True);self.player.pack(fill='x')
        self.update_idletasks();self.details_canvas.yview_moveto(0);self.player.play(self.doc.channel(ids[0]))
    def open_scanner(self):
        if not self.doc.channels:self.error('Open a playlist before scanning.');return
        self.scan_windows=[w for w in self.scan_windows if w.winfo_exists()]
        if self.scan_windows:self.scan_windows[0].lift();return
        win=ScanWindow(self);self.scan_windows.append(win)
        if self.health_view.get()!='All channels' or self.search.get().strip():win.scope.set('Current view')
    def undo(self):
        if not self.resolve_form():return
        self.doc=self.history.undo(self.doc);self.current=None;self.refresh();self.status.set('Undone.')
    def redo(self):
        if not self.resolve_form():return
        self.doc=self.history.redo(self.doc);self.current=None;self.refresh();self.status.set('Redone.')
    def protect(self):
        if not self.resolve_form():return False
        if self.doc.fingerprint()==self.saved:return True
        choice=messagebox.askyesnocancel('Unsaved playlist','Save your playlist before replacing or closing it?',parent=self)
        return False if choice is None else self.save() if choice else True
    def new(self):
        if not self.protect():return
        self.doc=Playlist();self.path=None;self.current=None;self.active_group=None;self.active_groups=[];self.category_scroll={};self.history=History();self.saved=self.doc.fingerprint();self.search.set('');self.refresh();self.status.set('New playlist.')
    def import_mode(self):
        if not self.doc.channels and not self.doc.categories:return 'Replace current playlist'
        return ChoiceDialog(self,'Import playlist','Add these channels to your playlist, or replace it?',['Append to current playlist','Replace current playlist']).result
    def change_health_view(self):
        if not self.resolve_form():
            self.health_view.set(getattr(self,'previous_health_view','All channels'))
            return
        self.previous_health_view=self.health_view.get();self.refresh_table()
    def drop_files(self,paths):
        paths=[str(p) for p in paths]
        if not paths or any(pathlib.Path(p).suffix.lower() not in ('.m3u','.m3u8') or not pathlib.Path(p).is_file() for p in paths):
            self.error('Drop M3U or M3U8 playlist files.');return
        if self.open_paths(paths,'Replace current playlist') and self.doc.channels:
            channel=self.doc.ordered()[0]
            self.table.selection_set(channel.id);self.select_channel();self.play_selected()
    def open_files(self):
        paths=filedialog.askopenfilenames(parent=self,title='Open M3U playlist files',filetypes=[('M3U playlists','*.m3u *.m3u8'),('All files','*.*')])
        if not paths:return
        mode=self.import_mode()
        if mode:self.open_paths(paths,mode)
    def open_paths(self,paths,mode):
        if not self.resolve_form():return
        try:
            docs=[];warnings=[]
            for path in paths:
                data,w=parse(decode(pathlib.Path(path).read_bytes()),pathlib.Path(path).stem);docs.append(data);warnings.extend(w)
            combined=docs[0]
            for d in docs[1:]:combined.merge(d)
            if mode.startswith('Replace'):
                if not self.protect():return
                self.doc=combined;self.path=str(paths[0]) if len(paths)==1 else None;self.current=None;self.active_group=None;self.history=History();self.saved=self.doc.fingerprint() if len(paths)==1 else '';self.health_view.set('All channels');self.scan_results.clear();self.last_scan_report=None;self.search.set('');self.refresh()
            else:self.commit(lambda:self.doc.merge(combined),f'Added {len(combined.channels):,} channels.')
            if mode.startswith('Replace') and len(paths)==1:self.remember_playlist(paths[0])
            self.status.set(f'Imported {len(combined.channels):,} channels from {len(paths)} file(s).')
            if warnings:messagebox.showwarning('Import notes',f'{len(warnings)} note(s). Channels with missing links remain editable.\n\n'+'\n'.join(warnings[:12]),parent=self)
            return True
        except Exception as ex:self.error(ex);return False
    def import_link(self):
        url=simpledialog.askstring('Import playlist link','Paste the raw M3U / M3U8 playlist URL:',parent=self)
        if not url:return
        url=url.strip()
        if urllib.parse.urlsplit(url).scheme.lower() not in ('http','https'):
            self.error('Enter an HTTP or HTTPS playlist link.');return
        mode=self.import_mode()
        if not mode:return
        self.status.set('Downloading playlist… You can keep working.')
        def worker():
            try:self.events.put(('import',fetch_playlist(url),mode))
            except Exception as ex:self.events.put(('error',str(ex)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            while True:
                item=self.events.get_nowait()
                if item[0]=='error':self.status.set('Import failed. Your playlist was not changed.');self.error(item[1])
                elif item[0]=='import':
                    (doc,warnings),mode=item[1:]
                    if mode.startswith('Replace'):
                        if not self.protect():continue
                        self.doc=doc;self.path=None;self.current=None;self.active_group=None;self.history=History();self.saved='';self.health_view.set('All channels');self.scan_results.clear();self.last_scan_report=None;self.search.set('');self.refresh()
                    else:
                        if not self.resolve_form():continue
                        self.commit(lambda:self.doc.merge(doc),'Imported playlist.')
                    self.status.set(f'Imported {len(doc.channels):,} channels from the link.')
                    if warnings:messagebox.showwarning('Import notes','\n'.join(warnings[:12]),parent=self)
                elif item[0]=='logo':
                    im=item[2];self.logo_cache[item[3]]=im
                    if len(self.logo_cache)>64:self.logo_cache.pop(next(iter(self.logo_cache)))
                    if item[1]==self.preview_token:self.logo_image=ImageTk.PhotoImage(im);self.logo_label.configure(image=self.logo_image,text='',width=96,height=70);self.logo_status.configure(text='Channel logo')
                elif item[0]=='logo_error' and item[1]==self.preview_token:self.logo_status.configure(text='Logo unavailable. Use Refresh to retry.');self.logo_label.configure(text='TV')
        except queue.Empty:pass
        self.after(100,self.poll)
    def save(self,save_as=False):
        if self.form_dirty and not self.apply_channel():return False
        try:text=serialize(self.doc)
        except Exception as ex:self.error(ex);return False
        missing=sum(not c.url for c in self.doc.channels)
        if missing and not messagebox.askyesno('Missing stream URLs',f'{missing} channel(s) have no stream URL. Keep these editable entries in the saved file?',parent=self):return False
        path=self.path
        if save_as or not path:path=filedialog.asksaveasfilename(parent=self,title='Save M3U playlist',defaultextension='.m3u',initialfile=pathlib.Path(path).name if path else self.doc.name+'.m3u',filetypes=[('M3U playlist','*.m3u'),('M3U8 playlist','*.m3u8')])
        if not path:return False
        try:self.backup_before_save(path);save_atomic(path,text);self.path=path;self.remember_playlist(path);app_settings.clear_recovery();self.saved=self.doc.fingerprint();self.update_title();self.status.set(f'Saved {len(self.doc.channels):,} channels to {path}');return True
        except Exception as ex:self.error(ex);return False

    def bdix_audit(self):
        if not self.doc.channels:
            messagebox.showinfo('BDIX Audit','Open or pull a playlist first.',parent=self);return
        rows=audit_playlist(self.doc);counts={}
        for r in rows:
            for f in r['flags']:counts[f]=counts.get(f,0)+1
        win=tk.Toplevel(self);win.title('BDIX-IPTV Audit');win.configure(bg=PANEL);win.geometry('980x680');win.transient(self)
        body=ttk.Frame(win,padding=16);body.pack(fill='both',expand=True)
        ttk.Label(body,text='BDIX-IPTV Audit',style='Title.TLabel').pack(anchor='w')
        summary='  '.join(f'{k}: {v}' for k,v in counts.items()) if counts else 'No audit flags found.'
        ttk.Label(body,text=summary,style='Muted.TLabel',wraplength=920).pack(anchor='w',pady=(7,12))
        tree=ttk.Treeview(body,columns=('channel','group','flags'),show='headings');tree.heading('channel',text='Channel');tree.heading('group',text='Group');tree.heading('flags',text='Flags');tree.column('channel',width=300);tree.column('group',width=180);tree.column('flags',width=420);tree.pack(fill='both',expand=True)
        for r in rows:
            if r['flags']:
                c=r['channel'];tree.insert('', 'end', values=(c.name,c.attrs.get('group-title',''),', '.join(r['flags'])))
        ttk.Button(body,text='Close',command=win.destroy).pack(anchor='e',pady=(10,0))

    def xtream_manager(self):
        win=tk.Toplevel(self);win.title('Xtream Codes');win.configure(bg=PANEL);win.geometry('620x420');win.transient(self)
        body=ttk.Frame(win,padding=20);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Xtream Codes login',style='Title.TLabel').pack(anchor='w');ttk.Label(body,text='Credentials are used for the live request and kept in memory only.',style='Muted.TLabel',wraplength=560).pack(anchor='w',pady=(6,14))
        fields={}
        for k,label in [('server','Server URL'),('username','Username'),('password','Password')]:
            ttk.Label(body,text=label,style='Muted.TLabel').pack(anchor='w',pady=(6,3));v=tk.StringVar();fields[k]=v;ttk.Entry(body,textvariable=v,show='•' if k=='password' else '').pack(fill='x')
        status=tk.StringVar(value='Not connected');ttk.Label(body,textvariable=status,style='Muted.TLabel').pack(anchor='w',pady=12)
        def login():
            try:
                c=XtreamConfig(**{k:v.get().strip() for k,v in fields.items()});base,data=xtream_login(c);self.xtream_cfg=c;status.set(f"Authenticated: {data.get('user_info',{}).get('status','unknown')} — {base}")
                if messagebox.askyesno('Xtream login','Login successful. Import the provider M3U playlist now?',parent=win):
                    url=xtream_m3u_url(c);self.import_link_url(url,replace=False);win.destroy()
            except Exception as ex:self.error(ex)
        ttk.Button(body,text='Login & verify',command=login,style='Accent.TButton').pack(anchor='w')
        ttk.Button(body,text='Close',command=win.destroy).pack(anchor='e',pady=16)

    def stalker_manager(self):
        win=tk.Toplevel(self);win.title('Stalker Portal / MAC');win.configure(bg=PANEL);win.geometry('640x520');win.transient(self)
        body=ttk.Frame(win,padding=20);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Stalker Portal / MAC login',style='Title.TLabel').pack(anchor='w')
        ttk.Label(body,text='Connect to a compatible Stalker/MAG portal using its portal URL and MAC address. Credentials remain local and are never written to the playlist.',style='Muted.TLabel',wraplength=590).pack(anchor='w',pady=(6,14))
        fields={}
        for k,label,default in [('portal','Portal URL',''),('mac','MAC address',''),('profile','Device profile','MAG254')]:
            ttk.Label(body,text=label,style='Muted.TLabel').pack(anchor='w',pady=(6,3))
            v=tk.StringVar(value=default);fields[k]=v
            if k=='profile':
                w=ttk.Combobox(body,textvariable=v,values=['MAG250','MAG254','MAG256','MAG322','MAG324','Custom'],state='readonly')
            else:w=ttk.Entry(body,textvariable=v)
            w.pack(fill='x')
        status=tk.StringVar(value='Not connected');ttk.Label(body,textvariable=status,style='Muted.TLabel',wraplength=590).pack(anchor='w',pady=12)
        def login():
            try:
                from bdix_integration import StalkerConfig, stalker_login, stalker_m3u
                c=StalkerConfig(portal=fields['portal'].get().strip(),mac=fields['mac'].get().strip(),profile=fields['profile'].get().strip())
                token,info=stalker_login(c);self.stalker_cfg=c
                status.set(f"Authenticated — {info.get('profile','Stalker/MAG portal')}" + (f" · {info.get('portal','')}" if info.get('portal') else ''))
                if messagebox.askyesno('Stalker login','Login successful. Import the available live-TV channels now?',parent=win):
                    text=stalker_m3u(c,token);doc,w=parse(text,'Stalker Portal');self.doc.merge(doc);self.path=None;self.saved=self.doc.fingerprint();self.history=History();self.current=None;self.active_group=None;self.refresh();self.status.set(f'Imported {len(doc.channels):,} channels from Stalker Portal.');win.destroy()
            except Exception as ex:self.error(ex)
        rr=ttk.Frame(body);rr.pack(fill='x',pady=16);ttk.Button(rr,text='Login & verify',command=login,style='Accent.TButton').pack(side='left');ttk.Button(rr,text='Close',command=win.destroy).pack(side='right')
        win.bind('<Return>',lambda e:login());win.bind('<Escape>',lambda e:win.destroy())

    def import_link_url(self,url,replace=False):
        self.status.set('Downloading Xtream playlist…')
        def worker():
            try:self.events.put(('import',fetch_playlist(url),'Replace current playlist' if replace else self.import_mode()))
            except Exception as ex:self.events.put(('error',str(ex)))
        threading.Thread(target=worker,daemon=True).start()

    def find_new_channels(self):
        if not self.doc.channels:
            messagebox.showinfo('Find New Channels','Open or pull your current playlist first.',parent=self);return
        path=filedialog.askopenfilename(parent=self,title='Select source M3U playlist',filetypes=[('M3U playlists','*.m3u *.m3u8'),('All files','*.*')])
        if not path:return
        try:
            incoming,w=parse(decode(pathlib.Path(path).read_bytes()),pathlib.Path(path).stem)
            candidates=discover_new(self.doc,incoming)
            if not candidates:
                messagebox.showinfo('Find New Channels','No eligible new Music/Movie/Backup candidates were found.',parent=self);return
            names='\n'.join(f"• {c.channel.name} — {c.reason} — {c.source}" for c in candidates[:80])
            more='' if len(candidates)<=80 else f'\n…and {len(candidates)-80} more.'
            if messagebox.askyesno('New channel candidates',f'Found {len(candidates)} eligible candidates. Add all of them?\n\n{names}{more}',parent=self):
                before=self.doc.snapshot();added=import_candidates(self.doc,candidates);self.history.record(before);self.refresh();self.status.set(f'Added {len(added)} reviewed candidates.')
        except Exception as ex:self.error(ex)

    def apply_theme(self,name):
        self.theme_manager.apply(name,persist=True)
        self.status.set(f'Theme: {name}')

    def settings_menu(self):
        menu=tk.Menu(self,tearoff=False,bg='#18232b',fg='#eef7fa',activebackground='#24566a',activeforeground='#ffffff',borderwidth=1)
        menu.add_command(label='⚙  General Settings',command=self.playlist_settings)
        themes=tk.Menu(menu,tearoff=False,bg='#18232b',fg='#eef7fa',activebackground='#24566a',activeforeground='#ffffff',selectcolor=self.theme_manager.palette['accent'])
        theme_var=tk.StringVar(self,value=self.theme_manager.name)
        # Checkbutton entries share one StringVar, so exactly the active theme
        # carries a visible check mark. This is more legible than the tiny
        # radiobutton dot on Windows.
        for name in THEMES:
            themes.add_checkbutton(label=name,variable=theme_var,onvalue=name,offvalue='',indicatoron=True,selectcolor=self.theme_manager.palette['accent'],command=lambda n=name:self.apply_theme(n))
        menu.add_cascade(label='🎨  Themes',menu=themes)
        player=tk.Menu(menu,tearoff=False,bg='#18232b',fg='#eef7fa',activebackground='#24566a',activeforeground='#ffffff')
        for mode in ('Fit','Fill','Stretch'):
            player.add_radiobutton(label=mode,variable=self.player.view_mode,value=mode,command=self.player.update_view)
        menu.add_cascade(label='▶  Player Settings',menu=player)
        reopen=tk.BooleanVar(self,value=False)
        menu.add_checkbutton(label='↺  Reopen last playlist on start',variable=reopen,command=lambda:self.set_pref('reopen_last',bool(reopen.get())))
        menu.add_command(label='🗂  Open backups folder',command=self.open_backups_folder)
        menu.add_separator()
        menu.add_command(label='⌘  GitHub Integration',command=lambda:webbrowser.open('https://github.com/saeidrahmanbd/BDIX-IPTV'))
        xs=tk.Menu(menu,tearoff=False,bg='#18232b',fg='#eef7fa',activebackground='#24566a',activeforeground='#ffffff')
        xs.add_command(label='Xtream',command=self.xtream_manager)
        xs.add_command(label='MAC / Stalker',command=self.stalker_manager)
        menu.add_cascade(label='🔗  Xtream / Stalker',menu=xs)
        menu.add_command(label='ℹ  About',command=lambda:show_info(self))
        try:
            x=self.settings_button.winfo_rootx(); y=self.settings_button.winfo_rooty()+self.settings_button.winfo_height()
            menu.tk_popup(x,y)
        finally:
            menu.grab_release()

    def playlist_settings(self):
        if not self.resolve_form():return
        win=tk.Toplevel(self);win.title('Playlist & EPG settings');win.configure(bg=PANEL);win.geometry('620x560');win.transient(self);win.grab_set();body=ttk.Frame(win,padding=20);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Playlist & programme guide',style='Title.TLabel').pack(anchor='w');ttk.Label(body,text='EPG IDs match channels to the guide. A source URL supplies the listings.',style='Muted.TLabel',wraplength=560).pack(anchor='w',pady=(8,15))
        fields={};keys=[('name','Playlist name',self.doc.name),('epg','EPG source URLs (comma-separated)',self.doc.header.get('x-tvg-url',self.doc.header.get('url-tvg',self.doc.header.get('tvg-url','')))),('shift','Global EPG shift (hours)',self.doc.header.get('tvg-shift',''))]
        for k,label,value in keys:ttk.Label(body,text=label,style='Muted.TLabel').pack(anchor='w',pady=(7,4));v=tk.StringVar(value=value);fields[k]=v;ttk.Entry(body,textvariable=v).pack(fill='x')
        ttk.Label(body,text='Other playlist-header attributes (JSON)',style='Muted.TLabel').pack(anchor='w',pady=(14,5));other=self.textbox(body,5);other.insert('1.0',json.dumps({k:v for k,v in self.doc.header.items() if k not in ['x-tvg-url','url-tvg','tvg-url','tvg-shift']},ensure_ascii=False,indent=2))
        def accept():
            try:
                data=json.loads(other.get('1.0','end-1c'))
                if not isinstance(data,dict) or any(not isinstance(v,str) or not re.fullmatch(r'[\w-]+',k) for k,v in data.items()):raise PlaylistError('Header attributes must be a JSON object with valid names and text values.')
                name=single(fields['name'].get().strip(),'Playlist name')
                if not name:raise PlaylistError('Enter a playlist name.')
                for key,formkey in [('x-tvg-url','epg'),('tvg-shift','shift')]:
                    if fields[formkey].get():data[key]=fields[formkey].get().strip()
                for v in data.values():quote(v)
                before=self.doc.snapshot();self.doc.name=name;self.doc.header=data;self.history.record(before);win.destroy();self.refresh();self.status.set('Playlist settings updated.')
            except Exception as ex:self.error(ex)
        buttons=ttk.Frame(body);buttons.pack(fill='x',pady=18);ttk.Button(buttons,text='Apply settings',style='Accent.TButton',command=accept).pack(side='right');ttk.Button(buttons,text='Cancel',command=win.destroy).pack(side='right',padx=8)
    def copy_stream(self):self.clipboard_clear();self.clipboard_append(self.stream.get('1.0','end-1c'));self.status.set('Stream link copied.')
    def open_stream(self):
        url=self.stream.get('1.0','end-1c').strip().split('|')[0]
        if urllib.parse.urlsplit(url).scheme not in ('http','https'):self.error('Only http/https links can be opened here. Copy other links into your IPTV player.');return
        webbrowser.open(url)
    def logo_preview(self,refresh=False):
        self.logo_job=None
        if not self.current or Image is None:return
        url=self.fields['tvg-logo'].get().strip();self.preview_token+=1;token=self.preview_token
        if not url:self.logo_status.configure(text='No logo set.');return
        if self.logo_future:self.logo_future.cancel()
        try:is_remote=urllib.parse.urlsplit(url).scheme in ('http','https')
        except ValueError:self.logo_status.configure(text='Invalid logo URL.');return
        path=pathlib.Path(url) if not is_remote else None
        if path is not None and not path.is_absolute():path=(pathlib.Path(self.path).parent if self.path else pathlib.Path.cwd())/path
        key=url if is_remote else str(path)
        if not refresh and key in self.logo_cache:
            self.logo_image=ImageTk.PhotoImage(self.logo_cache[key]);self.logo_label.configure(image=self.logo_image,text='',width=96,height=70);self.logo_status.configure(text='Channel logo');return
        self.logo_status.configure(text='Loading logo…')
        events=self.events
        def worker():
            try:
                if is_remote:
                    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PlaylistStudio/2.8.2'}),timeout=5) as r:data=r.read(4*1024*1024+1)
                    if len(data)>4*1024*1024:raise ValueError('Logo too large')
                    with Image.open(io.BytesIO(data)) as source:source.thumbnail((96,70));im=source.convert('RGBA')
                else:
                    with Image.open(path) as source:source.thumbnail((96,70));im=source.convert('RGBA')
                events.put(('logo',token,im,key))
            except Exception:events.put(('logo_error',token))
        self.logo_future=self.logo_pool.submit(worker)
    def help(self):
        messagebox.showinfo('Playlist Studio 5.0 · Quick guide','Drop M3U/M3U8 files anywhere on the app to load and play, or use Open files / Import link. Right-click editable fields to paste. Multiple files can be combined without dropping duplicate streams.\n\nCategories: add, rename, delete, drag to reorder, or use ↑/↓.\nChannels: select one for details; Ctrl/Shift-click for bulk selection. A drag badge and highlighted destination show where channels will move. Escape cancels a drag.\n\nClick the ▶ icon beside a channel name, or choose ▶ Play, to watch at the top of the right-hand details panel. Pause, Stop, Retry, volume, and mute are below the video. The channel list stays visible while you watch. Scroll the details panel for metadata and the channel logo. DRM license acquisition is not supported.\n\nScan links opens the scan centre. View filters show dead links or results needing review. Export Excel saves the full scan report, regardless of the current view. Choose all channels, the current category, or selected channels. Dead results are separate from timeouts, restrictions and unverified streams. Nothing is deleted automatically; inspect results before removing selected entries.\n\nApply changes updates the working playlist. Save M3U writes the file. Undo/Redo covers edits and removals. Playlist / EPG edits global guide URLs.\n\nCtrl+O Open · Ctrl+S Save · Ctrl+Shift+S Save as\nCtrl+Z Undo · Ctrl+Y Redo · Ctrl+F Search\n\nInfo contains the developer credit and biography. Your playlists stay local. Playback, scanning, imports, automatically loaded channel logos and opened links contact their respective servers.',parent=self)
    def close_app(self):
        if self.protect():
            self.save_prefs();app_settings.clear_recovery();self.destroy()
    def destroy(self):
        if hasattr(self,'row_logos'):self.row_logos.close()
        self.logo_pool.shutdown(wait=False,cancel_futures=True)
        if self.player:self.player.shutdown()
        for window in self.scan_windows:
            if window.winfo_exists():window.close()
        self.clear_drag()
        for job in self.tk.call('after','info'):
            try:self.tk.call('after','cancel',job)
            except tk.TclError:pass
        super().destroy()

if __name__=='__main__':
    try:
        if sys.platform=='win32':
            import ctypes
            try:ctypes.windll.shcore.SetProcessDpiAwareness(1)
            except Exception:pass
        Studio().mainloop()
    except Exception as ex:
        try:messagebox.showerror('Playlist Studio could not start',str(ex))
        except Exception:raise

