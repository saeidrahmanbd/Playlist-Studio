"""Playlist Studio 5.0 — Fluent Dark editor UI.

A direct evolution of the 2.8.x editor workflow: command bar, category rail,
channel workbench, compact player and inspector. No dashboard/sidebar maze.
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from studio_extras import PlayerPane, show_info

BG='#071116'; PANEL='#0c1b22'; FIELD='#08151b'; INK='#eef7fa'; MUTED='#8fa8b2'
ACCENT='#35d8c2'; LINE='#1d3741'; BLUE='#4ea5ff'; WARN='#e7c66d'; RED='#ff8794'; GREEN='#67d89b'


def styles(app):
    s=ttk.Style(app); s.theme_use('clam')
    s.configure('.',background=PANEL,foreground=INK,font=('Segoe UI',10))
    s.configure('TFrame',background=PANEL); s.configure('Shell.TFrame',background=BG)
    s.configure('TLabel',background=PANEL,foreground=INK)
    s.configure('Muted.TLabel',background=PANEL,foreground=MUTED)
    s.configure('Title.TLabel',background=PANEL,foreground=INK,font=('Segoe UI Semibold',16))
    s.configure('Section.TLabel',background=PANEL,foreground=INK,font=('Segoe UI Semibold',10))
    s.configure('TButton',background='#142b34',foreground=INK,borderwidth=0,padding=(10,6))
    s.map('TButton',background=[('active','#1d3e49'),('disabled','#102129')],foreground=[('disabled','#5d747c')])
    s.configure('Accent.TButton',background='#137f78',foreground='#f3ffff',font=('Segoe UI Semibold',10),padding=(11,7))
    s.map('Accent.TButton',background=[('active','#18a99d'),('pressed','#106b66')])
    s.configure('Quiet.TButton',background=PANEL,foreground=MUTED,padding=(8,6))
    s.map('Quiet.TButton',foreground=[('active',ACCENT)])
    s.configure('Toolbar.TButton',background=BG,foreground=INK,padding=(10,6),borderwidth=0)
    s.map('Toolbar.TButton',background=[('active','#142b34')])
    s.configure('Command.TButton',background='#10242c',foreground=INK,padding=(10,6),borderwidth=1,relief='solid',font=('Segoe UI Semibold',9))
    s.map('Command.TButton',background=[('active','#193943'),('pressed','#0d3038')],foreground=[('active','#ffffff')])
    s.configure('Category.Treeview',background=PANEL,fieldbackground=PANEL,foreground=INK,rowheight=32,borderwidth=0)
    s.map('Category.Treeview',background=[('selected','#123f46')],foreground=[('selected',ACCENT)])
    s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=INK,rowheight=34,borderwidth=0)
    s.map('Treeview',background=[('selected','#17475a')],foreground=[('selected','#ffffff')])
    s.configure('Treeview.Heading',background='#122831',foreground='#a9bec5',padding=(8,8),font=('Segoe UI Semibold',9))
    s.map('Treeview.Heading',background=[('active','#183742')])
    s.configure('Filter.TRadiobutton',background=PANEL,foreground=MUTED,padding=(7,4))
    s.map('Filter.TRadiobutton',foreground=[('selected',ACCENT)])
    s.configure('TEntry',fieldbackground=FIELD,foreground=INK,insertcolor=INK,bordercolor=LINE,padding=7)
    s.configure('TCombobox',fieldbackground=FIELD,foreground=INK,arrowcolor=INK,padding=6)
    s.map('TCombobox',fieldbackground=[('readonly',FIELD)],foreground=[('readonly',INK)])
    s.configure('TNotebook',background=PANEL,borderwidth=0)
    s.configure('TNotebook.Tab',background=FIELD,foreground=MUTED,padding=(12,8),font=('Segoe UI Semibold',9))
    s.map('TNotebook.Tab',background=[('selected',LINE)],foreground=[('selected',ACCENT)])
    s.configure('Vertical.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,borderwidth=0)
    s.configure('Horizontal.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,borderwidth=0)
    s.configure('TSeparator',background=LINE)


def _button(parent,text,cmd,accent=False):
    return ttk.Button(parent,text=text,command=cmd,style='Accent.TButton' if accent else 'Command.TButton')


def build(app):
    styles(app)
    root=ttk.Frame(app,style='Shell.TFrame'); root.pack(fill='both',expand=True)

    # Compact Windows-style command bar.
    top=tk.Frame(root,bg=BG,height=58); top.pack(fill='x'); top.pack_propagate(False)
    brand=tk.Frame(top,bg=BG); brand.pack(side='left',padx=(16,10))
    brand_icon=tk.Canvas(brand,width=30,height=30,bg=BG,highlightthickness=0); brand_icon.pack(side='left'); app.brand_icon=brand_icon
    brand_icon.create_oval(2,2,28,28,outline=ACCENT,width=2); brand_icon.create_polygon(12,8,12,22,22,15,fill=ACCENT)
    tk.Label(brand,text='Playlist Studio',bg=BG,fg=INK,font=('Segoe UI Semibold',13)).pack(side='left',padx=8)
    tk.Label(brand,text='5.0',bg=BG,fg=MUTED,font=('Segoe UI',9)).pack(side='left')

    bar=tk.Frame(top,bg=BG); bar.pack(side='left',fill='x',expand=True,padx=8)
    for label,cmd in [('Open',app.open_files),('Import URL',app.import_link),('Save',app.save),('Save As',lambda:app.save(True))]:
        _button(bar,label,cmd).pack(side='left',padx=2,pady=11)
    _button(bar,'Sources ▾',app.import_mode).pack(side='left',padx=2,pady=11)
    _button(bar,'Xtream',app.xtream_manager).pack(side='left',padx=2,pady=11)
    _button(bar,'MAC / Stalker',app.stalker_manager).pack(side='left',padx=2,pady=11)

    right=tk.Frame(top,bg=BG); right.pack(side='right',padx=12)
    app.settings_button=ttk.Button(right,text='⚙  Settings',command=app.settings_menu,style='Toolbar.TButton'); app.settings_button.pack(side='left',pady=10)
    ttk.Button(right,text='Info',command=lambda:show_info(app),style='Toolbar.TButton').pack(side='left',padx=(3,0),pady=10)
    ttk.Button(right,text='?',command=app.help,style='Toolbar.TButton',width=3).pack(side='left',padx=(3,0),pady=10)

    sep=tk.Frame(root,bg=LINE,height=1); sep.pack(fill='x')

    # Three-pane media editor.
    work=ttk.Frame(root,style='Shell.TFrame'); work.pack(fill='both',expand=True,padx=10,pady=10)
    app.panes=ttk.Panedwindow(work,orient='horizontal'); app.panes.pack(fill='both',expand=True)

    # Category rail.
    side=ttk.Frame(app.panes,padding=(8,10)); app.panes.add(side,weight=0)
    head=tk.Frame(side,bg=PANEL); head.pack(fill='x',pady=(0,8))
    ttk.Label(head,text='PLAYLIST',style='Section.TLabel').pack(side='left')
    ttk.Button(head,text='+',width=2,command=app.add_category).pack(side='right')
    app.groups=ttk.Treeview(side,show='tree',selectmode='extended',style='Category.Treeview')
    app.groups.column('#0',width=188,minwidth=150)
    gs=ttk.Scrollbar(side,orient='vertical',command=app.groups.yview); gs.pack(side='right',fill='y'); app.groups.configure(yscrollcommand=gs.set); app.groups.pack(fill='both',expand=True)
    app.groups.bind('<<TreeviewSelect>>',app.select_group); app.groups.bind('<Double-1>',lambda e:app.rename_category())
    app.groups.bind('<ButtonPress-1>',lambda e:app.drag_start(e,'category'),add='+'); app.groups.bind('<ButtonRelease-1>',app.drag_end,add='+'); app.groups.bind('<B1-Motion>',app.drag_motion)
    for actions in [[('Rename',app.rename_category),('Delete',app.delete_category)],[('↑',lambda:app.move_category(-1)),('↓',lambda:app.move_category(1)),('A–Z',app.sort_categories)]]:
        rr=ttk.Frame(side); rr.pack(fill='x',pady=(6,0))
        for label,cmd in actions: ttk.Button(rr,text=label,command=cmd,style='Quiet.TButton').pack(side='left',fill='x',expand=True,padx=2)
    ttk.Label(side,text='Ctrl/Shift-click to select several categories. Drag to reorder; drop channels onto a category.',style='Muted.TLabel',wraplength=185).pack(anchor='w',pady=(10,2))

    # Channel editor.
    middle=ttk.Frame(app.panes,padding=(10,10)); app.panes.add(middle,weight=4)
    heading=ttk.Frame(middle); heading.pack(fill='x',pady=(0,7))
    app.group_heading=ttk.Label(heading,text='All channels',style='Title.TLabel'); app.group_heading.pack(side='left')
    heading_actions=ttk.Frame(heading); heading_actions.pack(side='right')
    ttk.Button(heading_actions,text='Duplicates',command=app.find_duplicates,style='Command.TButton').pack(side='left',padx=(0,6))
    ttk.Button(heading_actions,text='Scan',command=app.open_scanner,style='Command.TButton').pack(side='left',padx=(0,6))
    ttk.Button(heading_actions,text='▶  Play',command=app.play_selected,style='Accent.TButton').pack(side='left')
    toolbar=ttk.Frame(middle); toolbar.pack(fill='x',pady=(0,7))
    for label,cmd in [('+ Channel',app.add_channel),('Duplicate',app.duplicate),('Delete',app.delete_channels),('Move to…',app.move_selected),('↑',lambda:app.move_rows(-1)),('↓',lambda:app.move_rows(1)),('A–Z',app.sort_channels)]:
        ttk.Button(toolbar,text=label,command=cmd,style='Quiet.TButton').pack(side='left',padx=(0,3))
    searchrow=ttk.Frame(middle); searchrow.pack(fill='x',pady=(0,7))
    app.search=tk.StringVar(); app.search.trace_add('write',app.search_changed)
    app.search_entry=ttk.Entry(searchrow,textvariable=app.search); app.search_entry.pack(side='left',fill='x',expand=True)
    app.health_view=tk.StringVar(value='All channels')
    for label,value in [('All','All channels'),('Dead','Dead links only'),('Review','Needs review'),('Unscanned','Not scanned')]:
        ttk.Radiobutton(searchrow,text=label,value=value,variable=app.health_view,style='Filter.TRadiobutton',command=app.change_health_view).pack(side='left',padx=(7,0))

    table=ttk.Frame(middle); table.pack(fill='both',expand=True)
    app.channel_tab=table
    app.table=ttk.Treeview(table,columns=('name','group','health','url','epg','format'),displaycolumns=('name','group','health','url'),show='tree headings',selectmode='extended')
    app.table.column('#0',width=48,minwidth=48,stretch=False); app.table.heading('#0',text='▶')
    for key,label,width,minimum in [('name','Channel',220,140),('group','Group',150,100),('health','Status',124,104),('url','Stream URL',240,110),('epg','EPG ID',100,70),('format','Format',65,55)]:
        app.table.heading(key,text=label,command=(lambda k=key:app.sort_by(k)) if key in app.SORT_LABELS else ''); app.table.column(key,width=width,minwidth=minimum,stretch=key in ('name','url'))
    sv=ttk.Scrollbar(table,orient='vertical',command=app.table.yview); sv.pack(side='right',fill='y')
    sh=ttk.Scrollbar(table,orient='horizontal',command=app.table.xview); sh.pack(side='bottom',fill='x')
    app.table.configure(yscrollcommand=sv.set,xscrollcommand=sh.set); app.table.pack(fill='both',expand=True)
    app.table.tag_configure('alternate',background='#0d242c'); app.table.tag_configure('missing',foreground=RED); app.table.tag_configure('dead',foreground=RED); app.table.tag_configure('review',foreground=WARN); app.table.tag_configure('drop',background='#194d48',foreground='#c4fff0')
    app.table.bind('<<TreeviewSelect>>',app.select_channel); app.table.bind('<ButtonPress-1>',app.channel_press,add='+'); app.table.bind('<ButtonRelease-1>',app.drag_end,add='+'); app.table.bind('<B1-Motion>',app.drag_motion); app.table.bind('<Motion>',app.channel_hover); app.table.bind('<Delete>',lambda e:app.delete_channels()); app.table.bind('<Control-a>',lambda e:app.select_all_visible())
    app.table.bind('<Escape>',lambda e:app.clear_drag())
    history=ttk.Frame(middle); history.pack(fill='x',pady=(6,0)); app.undo_button=ttk.Button(history,text='↶ Undo',command=app.undo,style='Quiet.TButton'); app.undo_button.pack(side='right'); app.redo_button=ttk.Button(history,text='↷ Redo',command=app.redo,style='Quiet.TButton'); app.redo_button.pack(side='right',padx=4)
    app.empty=ttk.Label(middle,text='',style='Muted.TLabel',wraplength=600); app.empty.pack(anchor='w',pady=(4,0))

    # Right media/inspector pane.
    details=ttk.Frame(app.panes,padding=(10,10)); app.panes.add(details,weight=1); app.inspector=details
    app.player_host=ttk.Frame(details); app.player_host.pack(fill='x')
    app.player=PlayerPane(app.player_host,app,compact=True); app.player.pack(fill='x')
    ttk.Separator(details).pack(fill='x',pady=(8,8))
    ttk.Label(details,text='CHANNEL',style='Section.TLabel').pack(anchor='w')
    app.selection_label=ttk.Label(details,text='Select a channel to edit.',style='Muted.TLabel'); app.selection_label.pack(anchor='w',pady=(3,6))
    bottom=ttk.Frame(details); bottom.pack(side='bottom',fill='x',pady=(7,0))
    app.apply_button=ttk.Button(bottom,text='Apply changes',style='Accent.TButton',command=app.apply_channel); app.apply_button.pack(side='right',fill='x',expand=True)
    ttk.Button(bottom,text='Revert',command=app.revert_form,style='Quiet.TButton').pack(side='left',padx=(0,6))
    outer=ttk.Frame(details); outer.pack(fill='both',expand=True)
    canvas=tk.Canvas(outer,bg=PANEL,highlightthickness=0,width=360); scroll=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview); canvas.configure(yscrollcommand=scroll.set); scroll.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
    app.details_canvas=canvas; app.form=ttk.Frame(canvas); window=canvas.create_window((0,0),window=app.form,anchor='nw'); app.form.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all'))); canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
    notebook=ttk.Notebook(app.form); notebook.pack(fill='both',expand=True); basic=ttk.Frame(notebook,padding=(2,7)); advanced=ttk.Frame(notebook,padding=(2,7)); notebook.add(basic,text='Info'); notebook.add(advanced,text='EPG & advanced'); notebook.bind('<<NotebookTabChanged>>',lambda e:canvas.yview_moveto(0))
    app.fields={}; app.widgets=[]
    for key,label in [('name','Channel name'),('category','Group / category'),('tvg-logo','Logo URL or file path'),('tvg-id','EPG / channel ID'),('tvg-name','EPG display name'),('tvg-chno','Channel number'),('tvg-language','Language'),('tvg-country','Country'),('tvg-url','Channel EPG URL'),('tvg-shift','EPG time shift (hours)'),('duration','EXTINF duration (-1 for live TV)')]:
        parent=basic if key in ('name','category','tvg-logo') else advanced
        ttk.Label(parent,text=label,style='Muted.TLabel').pack(anchor='w',pady=(5,3)); var=tk.StringVar(); var.trace_add('write',lambda *_:app.field_changed()); app.fields[key]=var
        w=ttk.Combobox(parent,textvariable=var,state='readonly') if key=='category' else ttk.Entry(parent,textvariable=var); w.pack(fill='x',pady=(0,3)); app.widgets.append(w)
        if key=='category':
            app.category_combo=w; ttk.Label(parent,text='Stream URL',style='Muted.TLabel').pack(anchor='w',pady=(5,3)); app.stream=app.textbox(parent,2); app.stream.bind('<<Modified>>',app.text_changed)
            rr=ttk.Frame(parent); rr.pack(fill='x',pady=(4,0)); ttk.Button(rr,text='Copy link',command=app.copy_stream,style='Quiet.TButton').pack(side='left'); ttk.Button(rr,text='Open link',command=app.open_stream,style='Quiet.TButton').pack(side='left',padx=5)
    logo=ttk.Frame(basic); logo.pack(fill='x',pady=7); app.logo_label=tk.Label(logo,text='TV',font=('Segoe UI Semibold',18),bg=FIELD,fg=ACCENT,width=5,height=2); app.logo_label.pack(side='left'); lr=ttk.Frame(logo); lr.pack(side='left',padx=9); ttk.Button(lr,text='Refresh logo',command=lambda:app.logo_preview(True),style='Quiet.TButton').pack(anchor='w'); app.logo_status=ttk.Label(lr,text='Select a channel to preview its logo.',style='Muted.TLabel',wraplength=220); app.logo_status.pack(anchor='w',pady=4)
    ttk.Label(advanced,text='Playback directives',style='Muted.TLabel').pack(anchor='w',pady=(8,4)); app.directives=app.textbox(advanced,4); app.directives.bind('<<Modified>>',app.text_changed); ttk.Label(advanced,text='#EXTVLCOPT, #KODIPROP and other options',style='Muted.TLabel',wraplength=320).pack(anchor='w',pady=4); ttk.Button(advanced,text='Additional attributes…',command=app.edit_attributes).pack(anchor='w',pady=7)
    app.advanced={}

    # Status bar.
    footer=tk.Frame(root,bg=BG,height=30); footer.pack(fill='x'); footer.pack_propagate(False)
    app.health_summary=tk.Label(footer,text='Ready',bg=BG,fg=ACCENT,font=('Segoe UI',9)); app.health_summary.pack(side='right',padx=12)
    app.status=tk.StringVar(value='Ready — open or import a playlist.'); tk.Label(footer,textvariable=app.status,bg=BG,fg=MUTED,font=('Segoe UI',9)).pack(side='left',padx=12)
    app.export_button=ttk.Button(footer,text='Export Excel…',command=lambda:_export_latest(app),state='disabled',style='Quiet.TButton'); app.export_button.pack(side='right')

    # Windows can emit another <Configure> event from sashpos(). Never call
    # sashpos recursively from the Configure handler. Apply the layout only
    # when it actually differs from the current layout, and coalesce repeated
    # Configure events through after_idle().
    app._fitting_panes=False
    app._last_pane_layout=None
    app._pane_fit_pending=False
    def fit_panes(event=None):
        # Keep the pending flag set for the whole sash update. On Windows,
        # sashpos() emits Configure synchronously; clearing the flag before
        # sashpos() creates an endless after_idle/configure loop.
        if app._pane_fit_pending or app._fitting_panes:
            return
        app._pane_fit_pending=True
        def apply_layout():
            try:
                if not app.winfo_exists():
                    return
                width=app.panes.winfo_width()
                if width<800:
                    return
                left=max(175,min(210,int(width*.15))); right=max(340,min(430,int(width*.28)))
                pref=getattr(app,'_pane_pref',None)
                if pref:
                    left=max(150,min(pref[0],420)); right=max(300,min(pref[1],700))
                    right=min(right,width-left-420)
                desired=(left,width-right)
                try:
                    current=(app.panes.sashpos(0),app.panes.sashpos(1))
                except Exception:
                    return
                if desired!=current:
                    app._fitting_panes=True
                    try:
                        app.panes.sashpos(0,left)
                        app.panes.sashpos(1,width-right)
                    finally:
                        app._fitting_panes=False
                if desired!=app._last_pane_layout:
                    app._last_pane_layout=desired
                    try:
                        app.player.video.configure(height=max(145,min(250,app.panes.winfo_height()-310)))
                    except Exception:
                        pass
            finally:
                app._pane_fit_pending=False
        app.after_idle(apply_layout)
    def remember_panes(event=None):
        # Remember the sash positions the person chose by dragging.
        try:
            width=app.panes.winfo_width()
            if width>=800 and not app._fitting_panes:
                app._pane_pref=(app.panes.sashpos(0),width-app.panes.sashpos(1))
        except Exception:
            pass
    app.panes.bind('<ButtonRelease-1>',remember_panes,add='+')
    app.panes.bind('<Configure>',fit_panes)
    app.panes.after(50,fit_panes)


def _export_latest(app):
    data=getattr(app,'last_scan_report',None)
    if not data or not data.get('results'):
        messagebox.showinfo('Scan report','Run Scan links to create a report.',parent=app); return
    path=filedialog.asksaveasfilename(parent=app,defaultextension='.xlsx',initialfile='Playlist-Stream-Scan.xlsx',filetypes=[('Excel workbook','*.xlsx')])
    if not path:return
    try:
        from scan_report import export_excel
        export_excel(path,data); app.status.set(f'Excel report saved: {path}')
    except Exception as error: app.error(error)
