"""Bounded stream inspection. No playlist mutation and no media downloads to disk."""
from __future__ import annotations
from dataclasses import dataclass
import urllib.request, urllib.parse, urllib.error, socket, time, threading
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

def stream_options(channel):
    url,sep,tail=channel.url.strip().partition('|')
    headers={'User-Agent':'PlaylistStudio/2.0'}
    names={'user-agent':'User-Agent','http-user-agent':'User-Agent','referer':'Referer','referrer':'Referer','http-referrer':'Referer','origin':'Origin','cookie':'Cookie','authorization':'Authorization'}
    for key,value in channel.attrs.items():
        if key.lower() in names and value:headers[names[key.lower()]]=value
    for line in channel.directives:
        if line.startswith('#EXTVLCOPT:'):
            key,_,value=line[11:].partition('=')
            if key.lower() in names:headers[names[key.lower()]]=value
    if sep:
        for key,value in urllib.parse.parse_qsl(tail,keep_blank_values=True):
            if key.lower() in names:headers[names[key.lower()]]=value
    if any('\n' in v or '\r' in v for v in headers.values()):raise ValueError('A playback header contains a line break.')
    return url,headers

def protected(channel):
    return any('license_key=' in x.lower() or 'license_type=' in x.lower() for x in channel.directives)

def evidence_key(channel):
    # Includes options, so a scan cannot be applied to a subsequently edited stream.
    return (channel.url,tuple(sorted(channel.attrs.items())),tuple(channel.directives))

@dataclass
class ScanResult:
    channel_id:str
    status:str
    detail:str
    elapsed:float
    key:tuple

class Cancelled(Exception):pass

def request_sample(url,headers,stop,timeout=6,limit=262144):
    if stop.is_set():raise Cancelled()
    req=urllib.request.Request(url,headers={**headers,'Accept':'*/*','Accept-Encoding':'identity'})
    with urllib.request.urlopen(req,timeout=timeout) as response:
        content_type=response.headers.get('Content-Type','').lower()
        # read1 does not wait to fill a large buffer on a live stream.
        chunks=[];size=0;end=time.monotonic()+timeout
        while size<limit:
            if stop.is_set():raise Cancelled()
            piece=response.read1(min(16384,limit-size))
            if not piece:break
            chunks.append(piece);size+=len(piece)
            data=b''.join(chunks)
            manifest=data.lstrip(b'\xef\xbb\xbf \r\n').startswith(b'#EXTM3U') or b'<MPD' in data[:4096]
            if not manifest and size>=2048:break
            if time.monotonic()>end:break
        return b''.join(chunks),content_type,response.geturl()

def media_bytes(data):
    if len(data)>=4 and data[:4] in (b'OggS',b'fLaC',b'\x1aE\xdf\xa3'):return True
    if data.startswith((b'ID3',b'FLV',b'RIFF')):return True
    if len(data)>12 and data[4:8] in (b'ftyp',b'styp',b'moof',b'mdat'):return True
    for i in range(min(188,len(data))):
        if i+376<len(data) and data[i]==data[i+188]==data[i+376]==0x47:return True
    return len(data)>2 and data[0]==255 and data[1]&0xe0==0xe0

def inspect_url(url,headers,stop,timeout=6,depth=0):
    if depth>4:return 'Unverified','Manifest nesting is too deep to verify.'
    data,ctype,final=request_sample(url,headers,stop,timeout)
    prefix=data.lstrip(b'\xef\xbb\xbf \r\n')
    if not data:return 'Unavailable','The server returned an empty response.'
    if b'<html' in prefix[:2048].lower() or b'<!doctype html' in prefix[:2048].lower():return 'Not a stream','The link returned a webpage instead of media.'
    if prefix.startswith(b'#EXTM3U'):
        lines=[x.strip() for x in data.decode('utf-8-sig',errors='replace').splitlines() if x.strip()]
        variants=[lines[i+1] for i,s in enumerate(lines[:-1]) if s.startswith('#EXT-X-STREAM-INF:') and not lines[i+1].startswith('#')]
        if variants:
            statuses=[]
            for variant in variants[:3]:
                try:
                    result=inspect_url(urllib.parse.urljoin(final,variant),headers,stop,timeout,depth+1)
                    if result[0]=='Responsive':return result
                    statuses.append(result)
                except (urllib.error.URLError,OSError):statuses.append(('Unavailable','A variant could not be reached.'))
            return 'Unverified','Master playlist responds, but sampled variants could not be verified.'
        if not any(s.startswith(('#EXT-X-TARGETDURATION','#EXT-X-MEDIA-SEQUENCE','#EXT-X-ENDLIST')) for s in lines):
            if any(s.startswith('#EXT-X-') for s in lines):return 'Unverified','An HLS manifest responds, but no supported media playlist was found.'
            return 'Not a stream','This is a channel playlist, not an individual HLS stream.'
        segments=[s for s in lines if not s.startswith('#')]
        if not segments:return 'Unverified','HLS manifest responds but has no media segments yet.'
        if any(s.startswith('#EXT-X-KEY:') and 'METHOD=NONE' not in s for s in lines):return 'Protected','Encrypted HLS manifest responds; key access and playback were not verified.'
        try:
            sample,stype,_=request_sample(urllib.parse.urljoin(final,segments[-1]),headers,stop,timeout,65536)
            if media_bytes(sample):return 'Responsive','HLS manifest and a media segment responded with media data.'
            return 'Unverified','HLS manifest responds, but sampled segment data was not recognized.'
        except urllib.error.HTTPError as ex:return 'Unavailable',f'HLS manifest responds, but a sampled segment returned HTTP {ex.code}.'
        except (urllib.error.URLError,OSError):return 'Unverified','HLS manifest responds; its sampled media segment could not be reached.'
    if b'<MPD' in prefix[:4096] or 'dash+xml' in ctype:return 'Unverified','DASH manifest responds; media segments and DRM were not verified.'
    if media_bytes(prefix):return 'Responsive','The server returned recognizable media data.'
    return 'Unverified','The URL responds, but the sample does not prove playable media.'

def scan_channel(channel,stop=None,timeout=6):
    stop=stop or threading.Event();start=time.monotonic();key=evidence_key(channel)
    def result(status,detail):return ScanResult(channel.id,status,detail,round(time.monotonic()-start,2),key)
    try:
        if not channel.url.strip():return result('Dead','Missing stream URL.')
        url,headers=stream_options(channel);parsed=urllib.parse.urlsplit(url)
        if parsed.scheme not in ('http','https'):return result('Unverified','This protocol needs a playback test; HTTP scanning does not verify it.')
        if not parsed.hostname:return result('Dead','Invalid HTTP URL: no host.')
        if protected(channel):return result('Protected','This channel has DRM/license directives; this scanner does not verify its license.')
        for attempt in range(2):
            try:return result(*inspect_url(url,headers,stop,timeout))
            except urllib.error.HTTPError as ex:
                if ex.code in (404,410):
                    if attempt==0:continue
                    return result('Dead',f'HTTP {ex.code} on two attempts: the stream URL was not found.')
                if ex.code in (401,403):return result('Restricted',f'HTTP {ex.code}: credentials, headers, or network access may be required.')
                return result('Unavailable',f'HTTP {ex.code}: the server is unavailable or refused the request.')
    except Cancelled:return result('Cancelled','Scan cancelled.')
    except (socket.timeout,TimeoutError):return result('Unreachable','Timed out. The stream may require your provider or BDIX network.')
    except urllib.error.URLError:return result('Unreachable','Connection, DNS, or certificate check failed. This does not prove the link is permanently dead.')
    except (ValueError,UnicodeError):return result('Unverified','The URL or its playback headers could not be parsed.')
    except OSError:return result('Unreachable','The connection failed or closed before inspection finished.')
    except Exception:return result('Unverified','The response could not be inspected.')

def scan_batch(channels,callback,stop,workers=6,timeout=6):
    items=iter(channels)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        pending=set()
        def submit():
            if stop.is_set():return
            try:pending.add(pool.submit(scan_channel,next(items),stop,timeout))
            except StopIteration:pass
        for _ in range(workers):submit()
        while pending:
            done,pending=wait(pending,timeout=.2,return_when=FIRST_COMPLETED)
            for task in done:
                value=task.result()
                if value.status!='Cancelled':callback(value)
                submit()
