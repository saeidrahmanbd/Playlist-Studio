"""Playlist Studio 5.0 startup + feature smoke test.

Runs the real Studio window for a few seconds with an isolated profile (nothing
in your real %APPDATA% is touched) and checks that:
  * the UI stays responsive and startup reaches the 'ready' stage (guards against
    the select_group re-entry freeze),
  * multi-category selection, column sorting and column visibility work,
  * the duplicate finder, bulk category delete, scan scopes, save-backups,
    autosave/recovery and saved preferences behave.

Exit code 0 = pass. Any failure prints the reason and exits non-zero, so
BUILD-WINDOWS.cmd stops before packaging a broken build.
"""
import faulthandler, os, sys, tempfile, time, types, ctypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'Source'))
PROFILE = tempfile.mkdtemp(prefix='ps5-smoke-')
os.environ['APPDATA'] = PROFILE
os.environ['TEMP'] = PROFILE
faulthandler.dump_traceback_later(90, exit=True)   # a hang fails the test instead of blocking the build

if sys.platform != 'win32':                          # allow running on Linux/macOS CI with Xvfb
    class _Dummy:
        def __getattr__(self, name): return lambda *a, **k: 0
    ctypes.WinDLL = lambda *a, **k: _Dummy()
    ctypes.get_last_error = lambda: 0
    ctypes.set_last_error = lambda v: None
    import desktop_support
    class _NoDrops:
        def __init__(self, app): pass
        def register(self, hwnd): pass
        def close(self): pass
    desktop_support.FileDrops = _NoDrops

import playlist_studio, studio_extras, app_settings, duplicates
from playlist_core import Channel, serialize

if sys.platform != 'win32':
    playlist_studio.FileDrops = desktop_support.FileDrops

failures = []
def check(condition, message):
    print(('  ok   ' if condition else '  FAIL ') + message, flush=True)
    if not condition: failures.append(message)

calls = {'select_group': 0}
_original = playlist_studio.Studio.select_group
def counted(self, event=None):
    calls['select_group'] += 1
    return _original(self, event)
playlist_studio.Studio.select_group = counted

app = playlist_studio.Studio()
app.geometry('1480x900+0+0')
ticks = []
def tick():
    ticks.append(time.monotonic()); app.after(100, tick)
app.after(100, tick)

def names(): return [app.table.set(i, 'name') for i in app.table.get_children()]

def step_startup():
    print('Startup', flush=True)
    gaps = [b - a for a, b in zip(ticks, ticks[1:])]
    check(app._startup_stage == 'ready', f'startup stage is "{app._startup_stage}"')
    check(len(ticks) > 10 and max(gaps or [9]) < 1.0, f'UI responsive (max gap {max(gaps or [9]):.2f}s)')
    check(calls['select_group'] < 50, f'select_group ran {calls["select_group"]} times (no re-entry loop)')
    for group, items in [('Alpha', [('Zed', 'http://x/1'), ('alpha 10', 'http://x/dup'), ('alpha 2', 'http://x/3')]),
                         ('Beta', [('Beta One', 'http://x/dup/'), ('Beta One', 'http://x/5')]),
                         ('Gamma', [('Gamma', 'http://x/6')])]:
        cat = app.doc.ensure_category(group)
        for name, url in items: app.doc.channels.append(Channel(name, url, cat, {}))
    app.refresh(); app.update()

def step_multiselect():
    print('Multi-category selection', flush=True)
    ids = [c.id for c in app.doc.categories]
    app.groups.selection_set(ids[0], ids[1])
def step_multiselect_check():
    check(str(app.groups.cget('selectmode')) == 'extended', 'category list uses extended selection')
    check(len(app.active_groups) == 2 and len(app.table.get_children()) == 5, f'two categories show 5 channels (got {len(app.table.get_children())})')
    check('group' in app.table['displaycolumns'], 'Group column visible with several categories')

def step_single():
    app.groups.selection_set(app.doc.categories[2].id)
def step_single_check():
    check('group' not in app.table['displaycolumns'], 'Group column hidden for a single category')
    app.groups.selection_set(app.doc.categories[0].id)
def step_sort():
    print('Column sorting', flush=True)
    app.update(); app.sort_by('name')
def step_sort_check():
    check(names() == ['alpha 2', 'alpha 10', 'Zed'], f'ascending natural sort ({names()})')
    app.sort_by('name'); app.update()
    check(names() == ['Zed', 'alpha 10', 'alpha 2'], f'descending sort ({names()})')
    check('▼' in app.table.heading('name', 'text'), 'header shows sort arrow')
    app.sort_by('name'); app.update()
    check(app.sort_state is None and names() == ['Zed', 'alpha 10', 'alpha 2'], 'third click restores playlist order')

def step_dups():
    print('Duplicate finder', flush=True)
    by_url = duplicates.find_duplicates(app.doc, duplicates.MODES[0])
    by_name = duplicates.find_duplicates(app.doc, duplicates.MODES[1])
    check(len(by_url) == 1 and len(by_url[0][1]) == 2, 'same-URL group found (trailing slash ignored)')
    check(len(by_name) == 1 and by_name[0][1][0].name == 'Beta One', 'same-name-in-category group found')
    app.find_duplicates(); app.update()
    window = app.dup_window
    check(window.winfo_exists() and bool(window.groups), 'duplicate window opens with results')
    window.select_extras(); check(len(window.tree.selection()) == 1, 'select extras keeps the first of each group')
    window.destroy()

def step_scope():
    print('Scan scope', flush=True)
    studio_extras.scan_batch = lambda channels, callback, stop: None
    app.groups.selection_set(app.doc.categories[0].id); app.update()
    app.search.set('10'); app.update(); app.after(400)   # matches only 'alpha 10'
def step_scope_check():
    app.open_scanner(); win = app.scan_windows[-1]
    check(win.scope.get() == 'Current view', 'scanner defaults to "Current view" while filtering')
    win.start(); win.update()
    check(len(win.channels) == 1, f'scan covers only the visible channel (got {len(win.channels)})')
    win.close(); app.search.set('')

def step_bulk_delete():
    print('Bulk category delete', flush=True)
    class Choice:
        def __init__(self, parent, title, message, choices): self.result = [c for c in choices if c.startswith('Delete')][0]
    playlist_studio.ChoiceDialog = Choice
    ids = [c.id for c in app.doc.categories]
    app.groups.selection_set(ids[1], ids[2]); app.update(); app.after(300)
def step_bulk_delete_check():
    app.delete_category(); app.update()
    check([c.name for c in app.doc.categories] == ['Alpha'], f'two categories deleted at once ({[c.name for c in app.doc.categories]})')
    app.undo(); app.update()
    check(len(app.doc.categories) == 3, 'undo restores them')

def step_backup_recovery():
    print('Backups, autosave and recovery', flush=True)
    target = Path(PROFILE) / 'list.m3u'; target.write_text('#EXTM3U\n', encoding='utf-8')
    backup = app_settings.backup_file(target)
    check(backup is not None and backup.is_file() and backup.suffix == '.bak', 'save creates a timestamped .bak')
    app.doc.channels.append(Channel('Unsaved', 'http://x/u', app.doc.categories[0].id, {}))
    app.autosave()
    found = app_settings.read_recovery()
    check(found is not None and 'Unsaved' in found[0], 'autosave writes a recovery copy of unsaved edits')
    app.saved = app.doc.fingerprint(); app.autosave()
    check(app_settings.read_recovery() is None, 'recovery copy removed once the playlist is clean')
    app_settings.write_recovery(serialize(app.doc), {'name': 'X', 'channels': 9, 'time': 'now'})
    playlist_studio.messagebox.askyesno = lambda *a, **k: True
    check(app.check_recovery() is True and any(c.name == 'Unsaved' for c in app.doc.channels), 'recovery restores the playlist')
    app_settings.clear_recovery()

def step_prefs():
    print('Saved preferences', flush=True)
    app.update(); app.geometry('1300x800+30+30'); app.update(); app.update()
    app.save_prefs()
    data = app_settings.load()
    check(isinstance(data.get('window'), dict) and data['window']['w'] >= 1080, f'window size saved ({data.get("window")})')
    check('volume' in data or app.player is None, 'player volume saved')
    app.remember_playlist(Path(PROFILE) / 'list.m3u')
    check(app_settings.load().get('last_playlist', '').endswith('list.m3u'), 'last playlist remembered')

def finish():
    print('\nRESULT: ' + ('PASS' if not failures else f'{len(failures)} FAILURE(S)'), flush=True)
    for f in failures: print(' -', f)
    app.quit()

steps = [step_startup, step_multiselect, step_multiselect_check, step_single, step_single_check, step_sort, step_sort_check,
         step_dups, step_scope, step_scope_check, step_bulk_delete, step_bulk_delete_check, step_backup_recovery, step_prefs, finish]
def run(i=0):
    if i >= len(steps): return
    try: steps[i]()
    except Exception as ex:
        import traceback; traceback.print_exc()
        failures.append(f'{steps[i].__name__} raised {type(ex).__name__}: {ex}')
    app.after(450, lambda: run(i + 1))
app.after(2500, run)   # let startup settle and collect timer ticks first
app.mainloop()
sys.exit(1 if failures else 0)
