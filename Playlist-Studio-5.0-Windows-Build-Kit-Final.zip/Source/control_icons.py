"""Antialiased player icons without font-dependent symbols."""
from PIL import Image, ImageDraw, ImageTk


def player_icons(master):
    icons = {}
    for name in ('play', 'pause', 'volume', 'muted'):
        image = Image.new('RGBA', (96, 96))
        draw = ImageDraw.Draw(image)
        color = '#edf4ff'
        if name == 'play':
            draw.ellipse((8, 8, 88, 88), outline=color, width=5)
            draw.polygon([(39, 29), (39, 67), (68, 48)], fill=color)
        elif name == 'pause':
            draw.rounded_rectangle((24, 20, 38, 76), radius=3, fill=color)
            draw.rounded_rectangle((58, 20, 72, 76), radius=3, fill=color)
        else:
            draw.polygon([(14, 37), (30, 37), (49, 20), (49, 76), (30, 59), (14, 59)], fill=color)
            if name == 'muted':
                draw.line((62, 36, 82, 60), fill='#ff919c', width=6)
                draw.line((82, 36, 62, 60), fill='#ff919c', width=6)
            else:
                draw.arc((32, 28, 73, 68), -60, 60, fill=color, width=5)
                draw.arc((22, 14, 89, 82), -60, 60, fill=color, width=5)
        icons[name] = ImageTk.PhotoImage(image.resize((28, 28), Image.Resampling.LANCZOS), master=master)
    return icons
