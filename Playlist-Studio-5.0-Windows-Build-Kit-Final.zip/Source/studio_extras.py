"""Player, scan centre and author panel for Playlist Studio."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import threading,queue,time,copy,json,os,sys
from PIL import Image,ImageTk,ImageOps
from pathlib import Path
from datetime import datetime
from stream_support import stream_options,protected,evidence_key,scan_batch
from playback_worker import PlaybackSupervisor
from player_input import PlayerInput
from player_controls import VideoControls
from native_video import FullscreenVideo,NativeVideoSurface

BG='#071419';PANEL='#0b1d23';FIELD='#08171d';INK='#edf8fa';MUTED='#9eb7c1';ACCENT='#36e5d5'
BIOGRAPHY=(
    'I am a marketing professional from Bangladesh with experience in brand management, product marketing, '
    'digital communication and campaign development.\n\n'
    'Alongside my professional work, I enjoy building practical technology and digital projects that combine '
    'problem-solving, design and real-world usability.\n\n'
    'Selected Projects\n\n'
    'Playlist Studio — A Windows application for managing, testing and maintaining IPTV playlists, with tools '
    'for M3U editing, stream scanning, EPG, logos, playback and reporting.\n\n'
    'BDIX IPTV — A Bangladesh-focused IPTV playlist project involving channel organization, stream verification, '
    'metadata, EPG, logos and backup management.\n\n'
    'My Approach\n\n'
    'Practical — solve a real problem.  Simple — keep complex processes easy to use.  Accurate — verify results '
    'instead of relying on assumptions.  Transparent — clearly show what changed and what needs attention.\n\n'
    'Understand the problem → simplify the workflow → build → test → improve.'
)


def show_info(app):
    import webbrowser

    win=tk.Toplevel(app)
    win.title('About · Playlist Studio')
    win.configure(bg=BG)
    win.geometry('760x820')
    win.minsize(680,650)
    win.transient(app)
    win.grab_set()

    # Scrollable content so the complete About + Contact section remains accessible
    # on smaller displays while the action buttons stay visible at the bottom.
    outer=ttk.Frame(win)
    outer.pack(fill='both',expand=True)

    canvas=tk.Canvas(outer,bg=BG,highlightthickness=0,borderwidth=0)
    scrollbar=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.pack(side='left',fill='both',expand=True)
    scrollbar.pack(side='right',fill='y')

    body=ttk.Frame(canvas,padding=30)
    body_id=canvas.create_window((0,0),window=body,anchor='nw')

    def refresh_scrollregion(_event=None):
        canvas.configure(scrollregion=canvas.bbox('all'))

    def resize_body(event):
        canvas.itemconfigure(body_id,width=event.width)
        refresh_scrollregion()

    body.bind('<Configure>',refresh_scrollregion)
    canvas.bind('<Configure>',resize_body)

    def wheel(event):
        canvas.yview_scroll(int(-event.delta/120),'units')

    canvas.bind('<MouseWheel>',wheel)
    body.bind('<MouseWheel>',wheel)

    ttk.Label(body,text='PLAYLIST STUDIO  /  5.0',foreground=ACCENT,font=('Segoe UI Semibold',11)).pack(anchor='w')
    ttk.Label(body,text='About Me',font=('Segoe UI Semibold',25)).pack(anchor='w',pady=(12,2))
    ttk.Label(body,text='SAEID RAHMAN',foreground=ACCENT,font=('Segoe UI Semibold',18)).pack(anchor='w',pady=(0,2))
    ttk.Label(body,text='Marketing Professional · Digital Projects · Technology Enthusiast',style='Muted.TLabel',wraplength=650).pack(anchor='w')
    ttk.Separator(body).pack(fill='x',pady=18)

    bio=ttk.Label(body,text=BIOGRAPHY,wraplength=650,justify='left')
    bio.pack(fill='x',anchor='w')

    ttk.Separator(body).pack(fill='x',pady=18)
    ttk.Label(body,text='Playlist Studio',font=('Segoe UI Semibold',14)).pack(anchor='w')
    ttk.Label(body,text='Playlist Studio 5.0',foreground=ACCENT,font=('Segoe UI Semibold',11)).pack(anchor='w',pady=(3,0))
    ttk.Label(body,text='M3U · IPTV · Stream Testing · EPG · Logos · Xtream · Stalker · Reporting',style='Muted.TLabel',wraplength=650).pack(anchor='w')
    ttk.Label(body,text='Developed by Saeid Rahman',style='Muted.TLabel').pack(anchor='w',pady=(3,0))

    ttk.Separator(body).pack(fill='x',pady=18)
    ttk.Label(body,text='Contact Me',font=('Segoe UI Semibold',14)).pack(anchor='w')

    def add_link(label,url,pady=(5,0)):
        link=ttk.Label(body,text=label,foreground=ACCENT,cursor='hand2')
        link.pack(anchor='w',pady=pady)
        link.bind('<Button-1>',lambda e,u=url: webbrowser.open(u))
        link.bind('<Enter>',lambda e: link.configure(font=('Segoe UI',9,'underline')))
        link.bind('<Leave>',lambda e: link.configure(font=('Segoe UI',9)))
        return link

    email='saeidrahman.mkt@gmail.com'
    add_link('Email: '+email,'mailto:'+email)
    add_link('Facebook: Saeid Rahman','https://www.facebook.com/saeidrahman',pady=(4,0))
    add_link('GitHub: saeidrahmanbd','https://github.com/saeidrahmanbd',pady=(4,0))
    add_link('GitHub Repository: BDIX-IPTV','https://github.com/saeidrahmanbd/BDIX-IPTV',pady=(4,0))
    add_link('Latest GitHub Release','https://github.com/saeidrahmanbd/BDIX-IPTV/releases/latest',pady=(4,0))
    ttk.Label(body,text='Location: Bangladesh',style='Muted.TLabel').pack(anchor='w',pady=(4,0))

    ttk.Separator(body).pack(fill='x',pady=18)
    ttk.Label(body,text='Playback powered by VideoLAN LibVLC. Third-party licenses and source code are bundled inside this portable app.',style='Muted.TLabel',wraplength=650).pack(anchor='w')

    # Keep actions fixed and always visible instead of placing them in the scroll area.
    buttons=ttk.Frame(win,padding=(30,8,30,14))
    buttons.pack(fill='x')
    ttk.Separator(buttons).pack(fill='x',pady=(0,10))
    ttk.Button(buttons,text='Licenses & source',command=lambda:os.startfile(str(Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/'Notices and Source'))).pack(side='left')
    ttk.Button(buttons,text='Close',command=win.destroy).pack(side='right')

    win.bind('<Escape>',lambda e:win.destroy())
    win.after(50,refresh_scrollregion)
    return win

class PlayerPane(ttk.Frame):
    def __init__(self,parent,app,compact=False):
        super().__init__(parent,padding=(0,6) if compact else 12);self.app=app;self.commands=queue.Queue();self.events=queue.Queue();self.started=False;self.closed=False;self.channel=None;self.paused=False;self.muted=False;self.seeking=False;self.state=0;self.generation=0
        self.fullscreen=None;self.surface=None;self.fullscreen_overlay=None;self.view_mode=tk.StringVar(value='Fit');self.last_view=None
        self.name=ttk.Label(self,text='Select a channel to watch',font=('Segoe UI Semibold',13 if compact else 17),wraplength=500);self.name.pack(anchor='w',pady=(0,3))
        self.note=ttk.Label(self,text='Drop a playlist here, or click the play icon beside a channel.',style='Muted.TLabel',wraplength=500);self.note.pack(anchor='w',pady=(0,8))
        self.video=tk.Frame(self,bg='#03060c',height=360 if compact else 420,highlightbackground='#2b4054',highlightthickness=1);self.video.pack(fill='x');self.video.pack_propagate(False)
        self.placeholder=tk.Frame(self.video,bg='#03060c',highlightthickness=0)
        self.placeholder_source=None;self.placeholder_image=None;self.placeholder_size=None
        asset=Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/'bdix_preview.png'
        try:
            with Image.open(asset) as source:self.placeholder_source=source.convert('RGB')
            self.placeholder_icon=tk.Label(self.placeholder,bg='#03060c',bd=0)
            self.placeholder_icon.pack(fill='both',expand=True)
            self.placeholder.bind('<Configure>',lambda e:self.fit_placeholder())
        except Exception:
            self.placeholder_icon=tk.Label(self.placeholder,text='BDIX-IPTV',bg='#03060c',fg=ACCENT,font=('Segoe UI Semibold',20))
            self.placeholder_icon.pack(expand=True)
        self.placeholder.place(relx=.5,rely=.5,anchor='center',relwidth=1,relheight=1)
        self.placeholder.after(50,self.fit_placeholder)
        self.position=tk.DoubleVar();self.volume=tk.DoubleVar(value=self._initial_volume());self.media_length=0;self.time_text='LIVE';self.controls=VideoControls(self.video,self)
        self.overlay_button=self.controls.fullscreen;self.input=PlayerInput(self)
        self.video.bind('<Configure>',lambda e:self.update_view());self.video.bind('<Double-1>',lambda e:self.toggle_fullscreen());self.app.bind('<F11>',lambda e:(self.toggle_fullscreen(),'break')[1])
        self.app.bind('<Escape>',lambda e:self.exit_fullscreen(),add='+')
        self.bind('<Configure>',lambda e:(self.name.configure(wraplength=max(220,e.width-24)),self.note.configure(wraplength=max(220,e.width-24))))
        self.job=self.after(100,self.poll)
    def _initial_volume(self):
        try:return max(0.0,min(100.0,float(getattr(self.app,'prefs',{}).get('volume',70))))
        except Exception:return 70.0
    def fit_placeholder(self):
        if self.closed or self.placeholder_source is None:return
        width=max(1,self.placeholder.winfo_width()-2);height=max(1,self.placeholder.winfo_height()-2)
        size=(width,height)
        if size==self.placeholder_size:return
        self.placeholder_size=size
        image=ImageOps.contain(self.placeholder_source,size,method=Image.Resampling.LANCZOS)
        self.placeholder_image=ImageTk.PhotoImage(image,master=self.placeholder_icon)
        self.placeholder_icon.configure(image=self.placeholder_image)

    def start_worker(self):
        if self.started:return
        if self.surface is None:self.surface=NativeVideoSurface(self.video)
        if getattr(self.app,'file_drops',None):self.app.file_drops.register(self.surface.hwnd)
        self.started=True;hwnd=self.surface.hwnd;self.raise_overlays()
        self.thread=PlaybackSupervisor(hwnd,self.commands,self.events);self.thread.settings['volume']=float(self.volume.get());self.thread.start()
    def play(self,channel):
        if not channel.url.strip():self.app.error('This channel has no stream URL. Add its link first.');return
        if protected(channel):self.app.error('This channel has DRM/license directives. The built-in player cannot acquire DRM licenses.');return
        try:url,headers=stream_options(channel)
        except Exception as ex:self.app.error(ex);return
        self.channel=copy.deepcopy(channel);self.generation+=1;self.name.configure(text=channel.name);self.note.configure(text='Connecting…');self.placeholder.place_forget();self.paused=False;self.start_worker();self.commands.put(('play',(self.generation,url,headers)))
        self.last_view=None;self.update_view()
        extra=set(headers)-{'User-Agent','Referer','Cookie'}
        if extra:self.note.configure(text='Connecting… This channel uses headers the built-in player may not support.')
    def pause(self):
        if self.state not in (3,4):return
        self.paused=not self.paused;self.commands.put(('pause',self.paused))
    def stop(self):self.commands.put(('stop',None));self.note.configure(text='Stopped.');self.paused=False;self.placeholder.place(relx=.5,rely=.5,anchor='center',relwidth=1,relheight=1)
    def retry(self):
        if self.channel:self.play(self.channel)
    def mute(self):self.muted=not self.muted;self.commands.put(('mute',self.muted))
    def seek(self,event=None):
        if self.media_length>0:self.commands.put(('seek',self.position.get()))
        self.seeking=False
    def add_fit_control(self,parent):
        ttk.Label(parent,text='View',style='Muted.TLabel').pack(side='left',padx=(0,6))
        combo=ttk.Combobox(parent,textvariable=self.view_mode,values=['Fit','Fill','Stretch'],state='readonly',width=9);combo.pack(side='left');combo.bind('<<ComboboxSelected>>',lambda e:self.update_view())
    def update_view(self):
        if self.closed:return
        if self.surface:self.surface.resize()
        self.raise_overlays()
        surface=self.fullscreen.host if self.fullscreen else self.video
        value=(self.view_mode.get(),max(1,surface.winfo_width()),max(1,surface.winfo_height()))
        if value!=self.last_view:self.last_view=value;self.commands.put(('view',value))
    def toggle_fullscreen(self):
        if self.fullscreen:self.exit_fullscreen();return
        if self.surface is None:self.surface=NativeVideoSurface(self.video)
        if getattr(self.app,'file_drops',None):self.app.file_drops.register(self.surface.hwnd)
        try:
            self.fullscreen=FullscreenVideo(self.app,self.surface,self.exit_fullscreen,lambda bar:None,self.update_view)
            self.fullscreen.window.bind('<space>',self.input.space);self.fullscreen_controls=VideoControls(self.fullscreen.host,self);self.fullscreen_overlay=self.fullscreen_controls.fullscreen;self.last_view=None;self.update_view()
        except Exception as ex:self.app.error(ex)
    def exit_fullscreen(self):
        if not self.fullscreen:return
        window=self.fullscreen;window.close();self.fullscreen=None;self.fullscreen_overlay=None;self.app.update_idletasks();self.app.details_canvas.yview_moveto(0);self.last_view=None;self.update_view()
    def make_fullscreen_icon(self,parent,command):
        icon=tk.PhotoImage(master=self,width=20,height=20)
        for rect in [(2,2,8,4),(2,2,4,8),(12,2,18,4),(16,2,18,8),(2,12,4,18),(2,16,8,18),(16,12,18,18),(12,16,18,18)]:icon.put('#ffffff',to=rect)
        button=tk.Button(parent,image=icon,command=command,bg='#101820',activebackground='#33465c',bd=0,highlightthickness=1,highlightbackground='#516074',cursor='hand2',width=32,height=28,takefocus=True);button.image=icon;button.place(relx=1,rely=1,x=-10,y=-10,anchor='se');return button
    def raise_overlays(self):
        for controls in [getattr(self,'controls',None),getattr(self,'fullscreen_controls',None)]:
            if controls and controls.winfo_exists() and controls.visible:
                controls.lift()
                if self.surface:self.surface.raise_widget(controls)
    def poll(self):
        if self.closed:return
        states={0:'Ready.',1:'Opening stream…',2:'Buffering…',3:'Playing',4:'Paused',5:'Stopped.',6:'Stream ended. Use Retry to reconnect.',7:'Playback failed. The provider may be offline, restricted, or incompatible.'}
        try:
            while True:
                item=self.events.get_nowait()
                if item[0]=='fatal':self.note.configure(text=item[1]);self.started=False;self.placeholder.place(relx=.5,rely=.5,anchor='center',relwidth=1,relheight=1)
                elif item[1]!=self.generation:continue
                elif item[0]=='error':self.note.configure(text=item[2]);self.placeholder.place(relx=.5,rely=.5,anchor='center',relwidth=1,relheight=1)
                else:
                    _,_,self.state,elapsed,length=item;self.note.configure(text=states.get(self.state,'Connecting…'));self.paused=self.state==4
                    self.time_text=f'{max(0,elapsed)//60000:02d}:{max(0,elapsed)//1000%60:02d}  /  '+(f'{length//60000:02d}:{length//1000%60:02d}' if length>0 else 'LIVE')
                    self.media_length=length
                    if length>0 and not self.seeking:self.position.set(max(0,elapsed)/length)
        except queue.Empty:pass
        # A newly spawned decoder can create its native video child after the
        # initial layout. Keep the playback controls above that child.
        self.raise_overlays()
        self.job=self.after(150,self.poll)
    def shutdown(self):
        self.exit_fullscreen()
        self.closed=True;self.input.close()
        if self.started:self.commands.put(('close',None))
        try:self.after_cancel(self.job)
        except tk.TclError:pass

class ScanWindow(tk.Toplevel):
    def __init__(self,app):
        super().__init__(app);self.app=app;self.title('Scan centre · Playlist Studio');self.configure(bg=BG);self.geometry('1100x670');self.minsize(850,520);self.results={};self.channels={};self.events=queue.Queue();self.stop_event=threading.Event();self.running=False;self.closed=False;self.result_view=tk.StringVar(value='All results')
        body=ttk.Frame(self,padding=20);body.pack(fill='both',expand=True)
        ttk.Label(body,text='Stream health',font=('Segoe UI Semibold',23)).pack(anchor='w');ttk.Label(body,text='Find dead links. Keep uncertain results separate.',foreground=ACCENT).pack(anchor='w',pady=(2,14))
        row=ttk.Frame(body);row.pack(fill='x');self.scope=tk.StringVar(value='All channels');ttk.Combobox(row,textvariable=self.scope,values=['All channels','Current category','Current view','Selected channels'],state='readonly',width=24).pack(side='left',padx=(0,8));self.start_button=ttk.Button(row,text='Start scan',style='Accent.TButton',command=self.start);self.start_button.pack(side='left');self.cancel_button=ttk.Button(row,text='Cancel',command=self.cancel,state='disabled');self.cancel_button.pack(side='left',padx=7)
        view=ttk.Combobox(row,textvariable=self.result_view,values=['All results','Response','Unverified','Restricted','Dead','Needs review'],state='readonly',width=20);view.pack(side='right');view.bind('<<ComboboxSelected>>',lambda e:self.refresh_results())
        ttk.Label(row,text='View ',style='Muted.TLabel').pack(side='right')
        self.progress=ttk.Progressbar(body,mode='determinate');self.progress.pack(fill='x',pady=(14,7));self.summary=ttk.Label(body,text='Ready. Six connections at a time; results reflect this network and this moment.',style='Muted.TLabel');self.summary.pack(anchor='w',pady=(0,10))
        table=ttk.Frame(body);table.pack(fill='both',expand=True);self.table=ttk.Treeview(table,columns=('name','category','status','detail'),show='headings',selectmode='extended',height=7)
        for k,label,width in [('name','CHANNEL',200),('category','CATEGORY',155),('status','RESULT',115),('detail','DETAILS',530)]:self.table.heading(k,text=label);self.table.column(k,width=width,minwidth=80)
        sv=ttk.Scrollbar(table,orient='vertical',command=self.table.yview);sv.pack(side='right',fill='y');sh=ttk.Scrollbar(table,orient='horizontal',command=self.table.xview);sh.pack(side='bottom',fill='x');self.table.configure(yscrollcommand=sv.set,xscrollcommand=sh.set);self.table.pack(fill='both',expand=True)
        for status,color in [('Dead','#ff919c'),('Responsive',ACCENT),('Restricted','#efc878'),('Unreachable','#efc878'),('Unavailable','#efc878'),('Unverified','#a8b7ce'),('Not a stream','#ffb195'),('Protected','#c5a4ef')]:self.table.tag_configure(status,foreground=color)
        self.table.bind('<Double-1>',self.detail)
        buttons=ttk.Frame(body);buttons.pack(fill='x',pady=(12,8))
        for label,command in [('Select dead',self.select_dead),('Remove selected…',self.remove),('Export Excel…',lambda:self.export('xlsx')),('Export JSON…',self.export),('Details',self.detail)]:ttk.Button(buttons,text=label,command=command).pack(side='left',padx=(0,7))
        ttk.Label(body,text='Responsive = media data received, not a decoding guarantee. Timeouts and access errors are not marked dead. No channels are removed automatically.',style='Muted.TLabel',wraplength=1000).pack(anchor='w')
        self.protocol('WM_DELETE_WINDOW',self.close);self.job=self.after(100,self.poll)
    def start(self):
        if self.running:return
        if not self.app.resolve_form():return
        scope=self.scope.get();selected=set(self.app.selected_ids());cats=set(self.app.active_groups) or ({self.app.active_group} if self.app.active_group else set());visible=set(self.app.table.get_children());source=[c for c in self.app.doc.ordered() if scope=='All channels' or scope=='Current category' and (not cats or c.category_id in cats) or scope=='Current view' and c.id in visible or scope=='Selected channels' and c.id in selected]
        if not source:messagebox.showinfo('Scan centre','No channels in this selection.',parent=self);return
        self.channels={c.id:copy.deepcopy(c) for c in source};self.categories={c.id:self.app.doc.category(c.category_id).name for c in source};self.results={};self.table.delete(*self.table.get_children());self.stop_event=threading.Event();self.running=True;self.start_button.state(['disabled']);self.cancel_button.state(['!disabled']);self.progress.configure(maximum=len(source),value=0);self.started_at=datetime.now().astimezone().isoformat(timespec='seconds');self.summary.configure(text=f'Scanning 0 / {len(source):,} channels…')
        for c in source:self.app.scan_results.pop(c.id,None)
        self.app.refresh_table()
        def worker():
            try:scan_batch(list(self.channels.values()),lambda r:self.events.put(('result',r)),self.stop_event)
            finally:self.events.put(('done',None))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        if self.closed:return
        changed=False
        try:
            while True:
                kind,result=self.events.get_nowait()
                if kind=='result':
                    self.results[result.channel_id]=result;self.app.scan_results[result.channel_id]=result;changed=True
                else:self.running=False;self.start_button.state(['!disabled']);self.cancel_button.state(['disabled']);changed=True
        except queue.Empty:pass
        if changed:
            self.app.last_scan_report=self.report_data()
            self.app.update_scan_summary()
            self.refresh_results()
            if not self.running:self.app.refresh_table()
            dead=sum(r.status=='Dead' for r in self.results.values());ok=sum(r.status=='Responsive' for r in self.results.values());self.progress.configure(value=len(self.results));self.summary.configure(text=f'{"Scanning" if self.running else "Cancelled" if self.stop_event.is_set() else "Complete"}  ·  {len(self.results):,} / {len(self.channels):,} checked  ·  {ok:,} response  ·  {dead:,} dead  ·  {len(self.results)-ok-dead:,} need review')
        self.job=self.after(120,self.poll)
    def cancel(self):self.stop_event.set();self.cancel_button.state(['disabled']);self.summary.configure(text='Cancelling… finishing requests already in progress.')
    def refresh_results(self):
        selected=self.table.selection();self.table.delete(*self.table.get_children())
        current_ids={c.id for c in self.app.doc.channels}
        for cid,r in self.results.items():
            if cid not in current_ids:continue
            view=self.result_view.get()
            if view=='Dead links only' and r.status!='Dead':continue
            if view=='Response' and r.status!='Responsive':continue
            if view=='Unverified' and r.status!='Unverified':continue
            if view=='Restricted' and r.status!='Restricted':continue
            if view=='Dead' and r.status!='Dead':continue
            if view=='Needs review' and r.status in ('Dead','Responsive'):continue
            self.table.insert('','end',iid=cid,values=(self.channels[cid].name,self.categories[cid],r.status,r.detail),tags=(r.status,))
        self.table.selection_set([cid for cid in selected if self.table.exists(cid)])
    def select_dead(self):
        self.result_view.set('Dead');self.refresh_results()
        self.table.selection_set(self.table.get_children())
    def detail(self,event=None):
        ids=self.table.selection()
        if not ids:return
        cid=ids[0];r=self.results[cid];messagebox.showinfo(self.channels[cid].name,f'{r.status}\n\n{r.detail}\n\nElapsed: {r.elapsed:.2f}s\nScan started: {self.started_at}\n\nThe stream URL is omitted here to avoid exposing access tokens.',parent=self)
    def remove(self):
        ids=set(self.table.selection())
        if not ids:return
        if self.running:messagebox.showinfo('Scan running','Finish or cancel the scan before removing entries.',parent=self);return
        if not self.app.resolve_form():return
        valid={c.id for c in self.app.doc.channels if c.id in ids and c.id in self.results and evidence_key(c)==self.results[c.id].key}
        if valid!=ids:messagebox.showinfo('Playlist changed','Some selected streams changed or were removed after scanning. Run a fresh scan before deleting these results.',parent=self);return
        if not messagebox.askyesno('Remove channels',f'Remove {len(valid)} selected channel(s) from the working playlist?\n\nUndo is available. Save the playlist to write the removal to disk.',parent=self):return
        if self.app.commit(lambda:setattr(self.app.doc,'channels',[c for c in self.app.doc.channels if c.id not in valid]),f'Removed {len(valid)} scanned channel(s). Undo is available.'):
            for cid in valid:self.table.delete(cid)
            self.refresh_results()
    def report_data(self):
        return {'scan_started':self.started_at,'scan_state':'In progress (partial)' if self.running else 'Cancelled (partial)' if self.stop_event.is_set() else 'Complete','scope_total':len(self.channels),'note':'A point-in-time network inspection. Responsive does not guarantee decoding; unreachable does not mean permanently dead. Stream URLs are omitted.','results':[{'channel':self.channels[cid].name,'category':self.categories[cid],'status':r.status,'detail':r.detail,'seconds':r.elapsed} for cid,r in self.results.items()]}
    def export(self,format='json'):
        if not self.results:return
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.'+format,initialfile='Playlist-Stream-Scan.'+format,filetypes=[('Excel workbook','*.xlsx')] if format=='xlsx' else [('JSON report','*.json')])
        if not path:return
        data=self.report_data()
        try:
            from playlist_core import save_atomic
            if format=='xlsx':
                from scan_report import export_excel
                export_excel(path,data)
            else:save_atomic(path,json.dumps(data,ensure_ascii=False,indent=2))
            messagebox.showinfo('Report exported',f'Saved {len(data["results"]):,} scan results to:\n{path}',parent=self)
        except Exception as ex:messagebox.showerror('Export failed',str(ex),parent=self)
    def close(self):
        self.closed=True;self.stop_event.set()
        try:self.after_cancel(self.job)
        except tk.TclError:pass
        self.destroy()
