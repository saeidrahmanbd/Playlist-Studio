"""Handle clicks on the native VLC child without intercepting other apps."""
import ctypes as C
from ctypes import wintypes as W
import tkinter as tk

class PlayerInput:
    def __init__(self,player):
        self.player=player;self.down=False;self.target=None
        self.api=C.WinDLL('user32')
        for name,result,args in [('GetAsyncKeyState',C.c_short,[C.c_int]),('WindowFromPoint',W.HWND,[W.POINT]),('IsChild',W.BOOL,[W.HWND,W.HWND])]:
            fn=getattr(self.api,name);fn.restype=result;fn.argtypes=args
        player.app.bind('<space>',self.space,add='+')
        self.bind_controls(player.controls)
        self.job=player.after(20,self.poll)
    def bind_controls(self,widget):
        widget.bind('<space>',self.space)
        for child in widget.winfo_children():self.bind_controls(child)
    def space(self,event):
        if event.widget.winfo_class() in ('Entry','TEntry','Text','TCombobox','Spinbox','TSpinbox'):return
        self.player.controls.play_pause();return 'break'
    def poll(self):
        p=self.player
        if p.closed:return
        down=bool(self.api.GetAsyncKeyState(1)&0x8000)
        if down and not self.down:
            self.target=None
            if p.surface:
                x,y=p.winfo_pointerxy();hit=self.api.WindowFromPoint(W.POINT(x,y));surface=p.surface.hwnd
                if hit==surface or self.api.IsChild(surface,hit):
                    self.target=(x,y);p.surface.current.focus_force()
        if not down and self.down and self.target:
            x,y=p.winfo_pointerxy();hit=self.api.WindowFromPoint(W.POINT(x,y));surface=p.surface.hwnd
            if (hit==surface or self.api.IsChild(surface,hit)) and abs(x-self.target[0])+abs(y-self.target[1])<8:p.controls.play_pause()
            self.target=None
        self.down=down;self.job=p.after(20,self.poll)
    def close(self):
        try:self.player.after_cancel(self.job)
        except tk.TclError:pass
