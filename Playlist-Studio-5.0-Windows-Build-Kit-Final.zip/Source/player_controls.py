"""Compact controls placed over the native video in either viewing mode."""
import tkinter as tk
import time
from control_icons import player_icons
from volume_slider import VolumeSlider

class VideoControls(tk.Frame):
    def __init__(self,parent,player):
        super().__init__(parent,bg='#07171d',height=62)
        self.player=player;self.last_pointer=None;self.active=time.monotonic();self.visible=True
        self.place(relx=0,rely=1,relwidth=1,anchor='sw');self.pack_propagate(False)
        self.seekbar=tk.Scale(self,from_=0,to=1,resolution=.001,orient='horizontal',showvalue=False,variable=player.position,bg='#07171d',troughcolor='#29545e',activebackground='#36e5d5',fg='white',highlightthickness=0,bd=0,sliderlength=10,width=4)
        self.seekbar.pack(fill='x',padx=8);self.seekbar.bind('<ButtonPress-1>',lambda e:setattr(player,'seeking',True));self.seekbar.bind('<ButtonRelease-1>',lambda e:self.seek())
        row=tk.Frame(self,bg='#07171d');row.pack(fill='x',padx=6)
        def button(text,command):
            b=tk.Button(row,text=text,command=command,bg='#07171d',fg='white',activebackground='#163a43',activeforeground='white',bd=0,font=('Segoe UI',12),cursor='hand2',width=2);b.pack(side='left');return b
        self.icons=player_icons(self)
        self.play_button=button('',self.play_pause)
        self.play_button.configure(image=self.icons['play'],width=32,height=30,takefocus=True)
        self.mute_button=button('',player.mute)
        self.mute_button.configure(image=self.icons['volume'],width=32,height=30,takefocus=True)
        self.volume=VolumeSlider(row,player.volume,lambda v:player.commands.put(('volume',float(v))))
        self.volume.pack(side='left',padx=(0,5));self.volume.bind('<Button-1>',self.set_volume);self.volume.bind('<B1-Motion>',self.set_volume)
        self.clock=tk.Label(row,text='LIVE',bg='#07171d',fg='white',font=('Segoe UI',8));self.clock.pack(side='left')
        self.fullscreen=player.make_fullscreen_icon(row,player.toggle_fullscreen);self.fullscreen.place_forget();self.fullscreen.pack(side='right')
        self.settings=tk.Menubutton(row,text='⚙',bg='#07171d',fg='white',activebackground='#163a43',activeforeground='white',bd=0,font=('Segoe UI',14),cursor='hand2');self.settings.pack(side='right',padx=4)
        menu=tk.Menu(self.settings,tearoff=False,bg='#222222',fg='white');self.settings.configure(menu=menu)
        for mode in ['Fit','Fill','Stretch']:menu.add_radiobutton(label=mode,variable=player.view_mode,value=mode,command=player.update_view)
        menu.add_separator();menu.add_command(label='Stop',command=player.stop);menu.add_command(label='Retry stream',command=player.retry)
        self.job=self.after(100,self.tick)
        self.bind('<Destroy>',self.cleanup)
        if hasattr(player,'input'):player.input.bind_controls(self)
    def cleanup(self,event):
        if event.widget==self:
            try:self.after_cancel(self.job)
            except tk.TclError:pass
    def play_pause(self):
        if self.player.state in (3,4):self.player.pause()
        else:self.player.retry()
    def set_volume(self,event):
        value=max(0,min(100,round(100*(event.x-10)/max(1,self.volume.winfo_width()-20))))
        self.player.volume.set(value);self.player.commands.put(('volume',value))
        if self.player.muted:self.player.mute()
        return 'break'
    def seek(self):
        if self.player.media_length>0:self.player.commands.put(('seek',self.player.position.get()))
        self.player.seeking=False
    def tick(self):
        p=self.player
        if p.closed:return
        self.play_button.configure(image=self.icons['pause' if p.state==3 else 'play']);self.mute_button.configure(image=self.icons['muted' if p.muted or p.volume.get()==0 else 'volume'])
        self.clock.configure(text=p.time_text);self.seekbar.configure(state='normal' if p.media_length>0 else 'disabled')
        xy=self.winfo_pointerxy();parent=self.master
        inside=parent.winfo_rootx()<=xy[0]<parent.winfo_rootx()+parent.winfo_width() and parent.winfo_rooty()<=xy[1]<parent.winfo_rooty()+parent.winfo_height()
        over=inside and xy[1]>=parent.winfo_rooty()+parent.winfo_height()-65
        focus=self.focus_get();focused=focus is not None and str(focus).startswith(str(self)+'.')
        if (inside and xy!=self.last_pointer) or over or focused or p.seeking or p.state!=3:self.active=time.monotonic()
        self.last_pointer=xy;show=time.monotonic()-self.active<2.5
        if show:
            self.place(relx=0,rely=1,relwidth=1,anchor='sw');self.lift()
            if p.surface:p.surface.raise_widget(self)
        else:self.place_forget()
        self.visible=show;self.job=self.after(100,self.tick)
