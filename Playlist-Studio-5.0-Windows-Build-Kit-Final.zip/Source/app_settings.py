"""Preferences, save-backups and crash recovery for Playlist Studio 5.0.

Everything lives under %APPDATA%\\Playlist Studio 5.0\\ (settings.json, backups\\,
recovery\\). All helpers are best-effort: a read-only profile or a damaged file
must never stop the editor from starting or saving.
"""
from __future__ import annotations
import glob, json, os, shutil, time
from pathlib import Path


def base_dir():
    return Path(os.environ.get('APPDATA') or Path.home()) / 'Playlist Studio 5.0'


def settings_path():
    return base_dir() / 'settings.json'


def load():
    try:
        data = json.loads(settings_path().read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def update(**values):
    """Merge values into settings.json (read-modify-write, atomic replace)."""
    try:
        path = settings_path(); path.parent.mkdir(parents=True, exist_ok=True)
        data = load(); data.update(values)
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(data, indent=2), encoding='utf-8')
        os.replace(temp, path)
    except Exception:
        pass


# ---------------------------------------------------------------- backups
def backup_dir():
    return base_dir() / 'backups'


def backup_file(path, keep=20):
    """Copy an existing playlist to the backups folder before it is overwritten.

    Backups are kept outside the playlist's own folder so a playlist repository
    (for example a GitHub checkout) is never cluttered. The newest `keep`
    backups per playlist name are retained.
    """
    source = Path(path)
    if not source.is_file():
        return None
    folder = backup_dir(); folder.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    target = folder / f'{source.stem}.{stamp}{source.suffix}.bak'
    shutil.copy2(source, target)
    pattern = f'{glob.escape(source.stem)}.[0-9]*-[0-9]*{glob.escape(source.suffix)}.bak'
    old = sorted(folder.glob(pattern))
    for stale in old[:-keep] if keep > 0 else []:
        try:
            stale.unlink()
        except OSError:
            pass
    return target


# --------------------------------------------------------------- recovery
def _recovery_files():
    folder = base_dir() / 'recovery'
    return folder / 'autosave.m3u', folder / 'autosave.json'


def write_recovery(text, meta):
    body, info = _recovery_files()
    body.parent.mkdir(parents=True, exist_ok=True)
    temp = body.with_suffix('.tmp')
    temp.write_text(text, encoding='utf-8')
    os.replace(temp, body)
    info.write_text(json.dumps(meta), encoding='utf-8')


def read_recovery():
    body, info = _recovery_files()
    try:
        if not body.is_file():
            return None
        text = body.read_text(encoding='utf-8')
        try:
            meta = json.loads(info.read_text(encoding='utf-8'))
        except Exception:
            meta = {}
        return text, meta if isinstance(meta, dict) else {}
    except Exception:
        return None


def clear_recovery():
    for path in _recovery_files():
        try:
            path.unlink()
        except OSError:
            pass
