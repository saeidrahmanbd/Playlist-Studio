"""Small ctypes LibVLC wrapper; runtime is bundled inside the standalone executable."""
import ctypes as C
import os,sys
from pathlib import Path

class VLCPlayer:
    def __init__(self,hwnd):
        base=Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).parent
        candidates=[Path(sys._MEIPASS)/'VLC'] if getattr(sys,'frozen',False) else [base/'VLC',base.parent/'VLC',base/'runtime/vlc-3.0.23',Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'VideoLAN/VLC']
        self.folder=next((p for p in candidates if (p/'libvlc.dll').exists()),None)
        if not self.folder:raise RuntimeError('The bundled playback engine could not be found. Please download a fresh copy of this executable.')
        self.dll_dir=os.add_dll_directory(str(self.folder));self.core=C.CDLL(str(self.folder/'libvlccore.dll'));self.lib=C.CDLL(str(self.folder/'libvlc.dll'));self.closed=False
        P=C.c_void_p;I=C.c_int;S=C.c_char_p
        signatures={'libvlc_new':(P,[I,C.POINTER(S)]),'libvlc_release':(None,[P]),'libvlc_media_player_new':(P,[P]),'libvlc_media_player_release':(None,[P]),'libvlc_media_new_location':(P,[P,S]),'libvlc_media_add_option':(None,[P,S]),'libvlc_media_release':(None,[P]),'libvlc_media_player_set_media':(None,[P,P]),'libvlc_media_player_set_hwnd':(None,[P,P]),'libvlc_media_player_play':(I,[P]),'libvlc_media_player_set_pause':(None,[P,I]),'libvlc_media_player_stop':(None,[P]),'libvlc_media_player_get_state':(I,[P]),'libvlc_audio_set_volume':(I,[P,I]),'libvlc_audio_set_mute':(None,[P,I]),'libvlc_media_player_get_time':(C.c_int64,[P]),'libvlc_media_player_get_length':(C.c_int64,[P]),'libvlc_media_player_set_position':(None,[P,C.c_float]),'libvlc_video_set_mouse_input':(None,[P,C.c_uint]),'libvlc_video_set_key_input':(None,[P,C.c_uint]),'libvlc_get_version':(S,[])}
        signatures.update({'libvlc_video_set_scale':(None,[P,C.c_float]),'libvlc_video_set_aspect_ratio':(None,[P,S]),'libvlc_video_set_crop_geometry':(None,[P,S])})
        for name,(rest,args) in signatures.items():fn=getattr(self.lib,name);fn.restype=rest;fn.argtypes=args
        os.environ['VLC_PLUGIN_PATH']=str(self.folder/'plugins')
        args=[b'--no-video-title-show',b'--no-snapshot-preview',b'--no-media-library',b'--no-osd',b'--quiet',b'--network-caching=1200']
        self.instance=self.lib.libvlc_new(len(args),(S*len(args))(*args))
        if not self.instance:raise RuntimeError('The bundled playback engine could not initialize.')
        self.player=self.lib.libvlc_media_player_new(self.instance)
        if not self.player:self.lib.libvlc_release(self.instance);raise RuntimeError('Could not create the video player.')
        self.lib.libvlc_media_player_set_hwnd(self.player,hwnd);self.lib.libvlc_video_set_mouse_input(self.player,0);self.lib.libvlc_video_set_key_input(self.player,0)
    def play(self,url,headers):
        media=self.lib.libvlc_media_new_location(self.instance,url.encode('utf-8'))
        if not media:raise RuntimeError('Could not open the stream address.')
        # Only documented playback options are forwarded, never arbitrary playlist commands.
        mapping={'User-Agent':'http-user-agent','Referer':'http-referrer','Cookie':'http-cookie'}
        try:
            for key,option in mapping.items():
                if headers.get(key):self.lib.libvlc_media_add_option(media,(':'+option+'='+headers[key]).encode('utf-8'))
            self.lib.libvlc_media_player_set_media(self.player,media)
        finally:self.lib.libvlc_media_release(media)
        if self.lib.libvlc_media_player_play(self.player)==-1:raise RuntimeError('Playback could not start.')
    def state(self):return self.lib.libvlc_media_player_get_state(self.player)
    def pause(self,paused):self.lib.libvlc_media_player_set_pause(self.player,int(paused))
    def stop(self):self.lib.libvlc_media_player_stop(self.player)
    def volume(self,value):self.lib.libvlc_audio_set_volume(self.player,int(float(value)))
    def mute(self,value):self.lib.libvlc_audio_set_mute(self.player,int(value))
    def time(self):return self.lib.libvlc_media_player_get_time(self.player)
    def length(self):return self.lib.libvlc_media_player_get_length(self.player)
    def seek(self,value):self.lib.libvlc_media_player_set_position(self.player,float(value))
    def view(self,mode,width,height):
        ratio=f'{max(1,int(width))}:{max(1,int(height))}'.encode('ascii')
        self.lib.libvlc_video_set_scale(self.player,0.0)
        self.lib.libvlc_video_set_aspect_ratio(self.player,ratio if mode=='Stretch' else None)
        self.lib.libvlc_video_set_crop_geometry(self.player,ratio if mode=='Fill' else None)
    def close(self):
        if self.closed:return
        self.closed=True;self.stop();self.lib.libvlc_media_player_release(self.player);self.lib.libvlc_release(self.instance);self.dll_dir.close()
