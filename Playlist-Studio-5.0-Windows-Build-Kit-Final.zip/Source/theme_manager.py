"""Playlist Studio 5.0 — visual theme system.

Themes are intentionally different in typography, density, control treatment,
selection treatment and surface hierarchy, not just accent color.
"""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk

THEMES = {'Dark Pro (Default)': {'bg': '#071116',
                        'panel': '#0c1b22',
                        'field': '#08151b',
                        'ink': '#eef7fa',
                        'muted': '#8fa8b2',
                        'accent': '#35d8c2',
                        'line': '#1d3741',
                        'button': '#142b34',
                        'active': '#1d3e49',
                        'selected': '#17475a',
                        'heading': '#122831',
                        'trough': '#0c1b22',
                        'family': 'Segoe UI',
                        'size': 10,
                        'title_size': 16,
                        'heading_size': 9,
                        'row': 34,
                        'cat_row': 32,
                        'button_pad': (10, 6),
                        'entry_pad': 7,
                        'tab_pad': (12, 8),
                        'relief': 'flat',
                        'border': 0},
 'Ocean Blue': {'bg': '#06111e',
                'panel': '#0b1b2c',
                'field': '#071526',
                'ink': '#eef7ff',
                'muted': '#8faac3',
                'accent': '#3fa9ff',
                'line': '#1e4161',
                'button': '#102a45',
                'active': '#19476f',
                'selected': '#185b8f',
                'heading': '#12304a',
                'trough': '#0b1b2c',
                'family': 'Segoe UI',
                'size': 10,
                'title_size': 16,
                'heading_size': 9,
                'row': 35,
                'cat_row': 33,
                'button_pad': (11, 7),
                'entry_pad': 8,
                'tab_pad': (13, 8),
                'relief': 'solid',
                'border': 1},
 'Green': {'bg': '#07150f',
           'panel': '#0d2118',
           'field': '#081810',
           'ink': '#effcf4',
           'muted': '#91b4a0',
           'accent': '#35d878',
           'line': '#24523a',
           'button': '#123323',
           'active': '#1b5135',
           'selected': '#17613a',
           'heading': '#123426',
           'trough': '#0d2118',
           'family': 'Segoe UI',
           'size': 10,
           'title_size': 16,
           'heading_size': 9,
           'row': 35,
           'cat_row': 34,
           'button_pad': (11, 7),
           'entry_pad': 8,
           'tab_pad': (13, 8),
           'relief': 'flat',
           'border': 0},
 'Purple': {'bg': '#100817',
            'panel': '#1b0d25',
            'field': '#12091a',
            'ink': '#f8efff',
            'muted': '#b19dbb',
            'accent': '#b56cff',
            'line': '#4a2861',
            'button': '#2a1539',
            'active': '#45225e',
            'selected': '#5b2782',
            'heading': '#321842',
            'trough': '#1b0d25',
            'family': 'Segoe UI',
            'size': 10,
            'title_size': 17,
            'heading_size': 9,
            'row': 36,
            'cat_row': 34,
            'button_pad': (12, 7),
            'entry_pad': 8,
            'tab_pad': (14, 9),
            'relief': 'solid',
            'border': 1},
 'Graphite': {'bg': '#0e1013',
              'panel': '#171a1f',
              'field': '#111419',
              'ink': '#e7eaee',
              'muted': '#9299a3',
              'accent': '#c5ccd6',
              'line': '#343a43',
              'button': '#22262d',
              'active': '#303640',
              'selected': '#3c4652',
              'heading': '#20242a',
              'trough': '#171a1f',
              'family': 'Segoe UI',
              'size': 10,
              'title_size': 16,
              'heading_size': 9,
              'row': 34,
              'cat_row': 32,
              'button_pad': (10, 6),
              'entry_pad': 7,
              'tab_pad': (12, 8),
              'relief': 'solid',
              'border': 1},
 'Glass Enhanced': {'bg': '#142333',
                    'panel': '#22384b',
                    'field': '#1a2e40',
                    'ink': '#f1f7fc',
                    'muted': '#b0c1cf',
                    'accent': '#75c8ff',
                    'line': '#5b7991',
                    'button': '#31536b',
                    'active': '#426f8d',
                    'selected': '#356b91',
                    'heading': '#2c465c',
                    'trough': '#22384b',
                    'family': 'Segoe UI',
                    'size': 10,
                    'title_size': 17,
                    'heading_size': 9,
                    'row': 36,
                    'cat_row': 34,
                    'button_pad': (12, 8),
                    'entry_pad': 8,
                    'tab_pad': (14, 9),
                    'relief': 'solid',
                    'border': 1},
 'Terminal': {'bg': '#030806',
              'panel': '#06110b',
              'field': '#020603',
              'ink': '#b8ffd1',
              'muted': '#58b77a',
              'accent': '#00ff66',
              'line': '#14552e',
              'button': '#0a2113',
              'active': '#0f3920',
              'selected': '#124e29',
              'heading': '#0b2415',
              'trough': '#06110b',
              'family': 'Consolas',
              'size': 9,
              'title_size': 15,
              'heading_size': 8,
              'row': 29,
              'cat_row': 28,
              'button_pad': (8, 4),
              'entry_pad': 5,
              'tab_pad': (9, 5),
              'relief': 'solid',
              'border': 1},
 'Neon Punk': {'bg': '#090611',
               'panel': '#130c1d',
               'field': '#0b0810',
               'ink': '#fff0fb',
               'muted': '#bca4bc',
               'accent': '#ff39c9',
               'line': '#5b1c5f',
               'button': '#25102c',
               'active': '#421546',
               'selected': '#67205f',
               'heading': '#28112f',
               'trough': '#130c1d',
               'family': 'Segoe UI',
               'size': 10,
               'title_size': 17,
               'heading_size': 9,
               'row': 35,
               'cat_row': 33,
               'button_pad': (12, 7),
               'entry_pad': 8,
               'tab_pad': (14, 8),
               'relief': 'solid',
               'border': 1},
 'Midnight': {'bg': '#090b12',
              'panel': '#121421',
              'field': '#0c0e17',
              'ink': '#eeeaf8',
              'muted': '#aaa6b8',
              'accent': '#d4a72c',
              'line': '#3d3558',
              'button': '#1d1a2b',
              'active': '#2b2540',
              'selected': '#3e3560',
              'heading': '#1a1826',
              'trough': '#121421',
              'family': 'Segoe UI',
              'size': 10,
              'title_size': 18,
              'heading_size': 9,
              'row': 36,
              'cat_row': 34,
              'button_pad': (12, 8),
              'entry_pad': 8,
              'tab_pad': (14, 9),
              'relief': 'solid',
              'border': 1}}


class ThemeManager:
    def __init__(self, app):
        self.app=app
        self.name=self._load_name()

    @property
    def palette(self):
        return THEMES[self.name]

    def _config_path(self):
        base=Path(os.environ.get("APPDATA") or Path.home())/"Playlist Studio 5.0"
        return base/"settings.json"

    def _load_name(self):
        legacy={
            "Dark (Default)":"Dark Pro (Default)",
            "Blue":"Ocean Blue",
            "Light":"Dark Pro (Default)",
            "Classic":"Dark Pro (Default)",
            "Solarized (Modified)":"Dark Pro (Default)",
            "Minimalist":"Dark Pro (Default)",
        }
        try:
            data=json.loads(self._config_path().read_text(encoding="utf-8"))
            name=legacy.get(data.get("theme"),data.get("theme"))
            if name in THEMES:return name
        except Exception:
            pass
        return "Dark Pro (Default)"

    def _save_name(self):
        try:
            p=self._config_path();p.parent.mkdir(parents=True,exist_ok=True)
            data={}
            if p.exists():
                try:data=json.loads(p.read_text(encoding="utf-8"))
                except Exception:data={}
            data["theme"]=self.name
            p.write_text(json.dumps(data,indent=2),encoding="utf-8")
        except Exception:
            pass

    def apply(self,name=None,persist=True):
        if name not in THEMES:name=self.name
        self.name=name
        p=self.palette
        self._update_module_palettes(p)
        self._style_ttk(p)
        self._walk(self.app,p)
        try:self.app.configure(bg=p["bg"])
        except Exception:pass
        if persist:self._save_name()

    def _update_module_palettes(self,p):
        import fluent_ui, studio_extras
        for module in (fluent_ui,studio_extras):
            for key in ("BG","PANEL","FIELD","INK","MUTED","ACCENT","LINE"):
                if hasattr(module,key):
                    setattr(module,key,p["bg"] if key=="BG" else p[key.lower()])
        mainmod=sys.modules.get("__main__")
        if mainmod is not None:
            for key in ("BG","PANEL","FIELD","INK","MUTED","ACCENT","LINE"):
                if hasattr(mainmod,key):
                    setattr(mainmod,key,p["bg"] if key=="BG" else p[key.lower()])

    def _style_ttk(self,p):
        s=ttk.Style(self.app)
        family=p["family"]; size=p["size"]
        s.configure(".",background=p["panel"],foreground=p["ink"],font=(family,size))
        s.configure("TFrame",background=p["panel"])
        s.configure("Shell.TFrame",background=p["bg"])
        s.configure("TLabel",background=p["panel"],foreground=p["ink"],font=(family,size))
        s.configure("Muted.TLabel",background=p["panel"],foreground=p["muted"],font=(family,size))
        s.configure("Title.TLabel",background=p["panel"],foreground=p["ink"],font=(family,p["title_size"],"bold"))
        s.configure("Section.TLabel",background=p["panel"],foreground=p["ink"],font=(family,size,"bold"))
        s.configure("TButton",background=p["button"],foreground=p["ink"],padding=p["button_pad"],borderwidth=p["border"],relief=p["relief"],font=(family,size))
        s.map("TButton",background=[("active",p["active"]),("disabled",p["panel"])])
        s.configure("Accent.TButton",background=p["accent"],foreground="#ffffff",padding=p["button_pad"],borderwidth=p["border"],relief=p["relief"],font=(family,size,"bold"))
        s.map("Accent.TButton",background=[("active",p["active"]),("pressed",p["line"])])
        s.configure("Quiet.TButton",background=p["panel"],foreground=p["muted"],padding=p["button_pad"],borderwidth=p["border"],relief=p["relief"],font=(family,size))
        s.map("Quiet.TButton",foreground=[("active",p["accent"])])
        s.configure("Toolbar.TButton",background=p["bg"],foreground=p["ink"],padding=p["button_pad"],borderwidth=p["border"],relief=p["relief"],font=(family,size))
        s.map("Toolbar.TButton",background=[("active",p["active"])])
        s.configure("Command.TButton",background=p["button"],foreground=p["ink"],padding=p["button_pad"],borderwidth=p["border"],relief=p["relief"],font=(family,size,"bold"))
        s.map("Command.TButton",background=[("active",p["active"]),("pressed",p["line"])])
        s.configure("Category.Treeview",background=p["panel"],fieldbackground=p["panel"],foreground=p["ink"],rowheight=p["cat_row"],borderwidth=p["border"])
        s.map("Category.Treeview",background=[("selected",p["selected"])],foreground=[("selected",p["accent"])])
        s.configure("Treeview",background=p["panel"],fieldbackground=p["panel"],foreground=p["ink"],rowheight=p["row"],borderwidth=p["border"],font=(family,size))
        s.map("Treeview",background=[("selected",p["selected"])],foreground=[("selected","#ffffff")])
        s.configure("Treeview.Heading",background=p["heading"],foreground=p["muted"],padding=p["tab_pad"],font=(family,p["heading_size"],"bold"))
        s.map("Treeview.Heading",background=[("active",p["active"])])
        s.configure("Filter.TRadiobutton",background=p["panel"],foreground=p["muted"],padding=p["button_pad"],font=(family,size))
        s.map("Filter.TRadiobutton",foreground=[("selected",p["accent"])])
        s.configure("TEntry",fieldbackground=p["field"],foreground=p["ink"],insertcolor=p["ink"],bordercolor=p["line"],padding=p["entry_pad"],font=(family,size))
        s.configure("TCombobox",fieldbackground=p["field"],foreground=p["ink"],arrowcolor=p["ink"],padding=p["entry_pad"],font=(family,size))
        s.map("TCombobox",fieldbackground=[("readonly",p["field"])],foreground=[("readonly",p["ink"])])
        s.configure("TNotebook",background=p["panel"],borderwidth=p["border"])
        s.configure("TNotebook.Tab",background=p["field"],foreground=p["muted"],padding=p["tab_pad"],font=(family,size,"bold"))
        s.map("TNotebook.Tab",background=[("selected",p["line"])],foreground=[("selected",p["accent"])])
        for name in ("Vertical.TScrollbar","Horizontal.TScrollbar"):
            s.configure(name,background=p["line"],troughcolor=p["trough"],arrowcolor=p["muted"],borderwidth=p["border"])
        s.configure("TSeparator",background=p["line"])

    def _walk(self,widget,p):
        try:
            cls=widget.winfo_class()
            family=p["family"]; size=p["size"]
            if cls in ("Frame","Labelframe"):
                widget.configure(bg=p["field"] if self._is_video_widget(widget) else p["panel"])
            elif cls in ("Label","Button","Menubutton"):
                kw={}
                if "background" in widget.keys():kw["bg"]=p["panel"]
                if "foreground" in widget.keys():kw["fg"]=p["ink"]
                if "activebackground" in widget.keys():kw["activebackground"]=p["active"]
                if "activeforeground" in widget.keys():kw["activeforeground"]=p["ink"]
                if cls=="Button":
                    kw["font"]=(family,size)
                if kw:widget.configure(**kw)
            elif cls in ("Text","Entry"):
                widget.configure(bg=p["field"],fg=p["ink"],insertbackground=p["ink"],font=(family,size))
            elif cls=="Canvas":
                widget.configure(bg=p["bg"] if widget==getattr(self.app,"brand_icon",None) else p["panel"])
            elif cls=="Scale":
                widget.configure(bg=p["button"],troughcolor=p["field"],activebackground=p["accent"],fg=p["ink"])
            elif cls=="Listbox":
                widget.configure(bg=p["field"],fg=p["ink"],selectbackground=p["selected"],selectforeground=p["ink"],font=(family,size))
        except Exception:
            pass
        for child in widget.winfo_children():
            self._walk(child,p)

    @staticmethod
    def _is_video_widget(widget):
        try:return str(widget).endswith(".video") or "03060c" in str(widget.cget("bg")).lower()
        except Exception:return False
