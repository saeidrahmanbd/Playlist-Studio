============================================================
                 PLAYLIST STUDIO 5.0
              INSTALLATION & USER GUIDE
============================================================


INSTALLATION
------------

1. Extract the "Playlist Studio 5.0" ZIP file to a folder.

2. Make sure Python is installed on your computer.

3. Open the extracted "Playlist Studio 5.0" folder and
   double-click:

       BUILD-Windows.cmd

4. A Command Prompt window will open.
   Wait a few minutes while the program is being built.
   Do not close the window.

5. When the build is completed, the program will be available
   in the main "Playlist Studio 5.0" folder.

6. Double-click:

       Playlist-Studio-5.0.exe

   You can also find the built program inside the "dist" folder.


------------------------------------------------------------

USER GUIDE
----------

OPEN PLAYLIST
-------------
• Click "Open" to load an M3U playlist.
• Click "Import URL" to load a playlist from a URL.


CATEGORIES
----------
• Click a category to view its channels.
• Hold Ctrl and click to select multiple categories.
• Hold Shift and click to select a range of categories.


CHANNELS
--------
• Select a channel to view or edit its information.
• Edit the channel name, category, stream URL, logo or EPG ID.
• Use "Duplicate", "Delete" and "Move to" when required.


PLAY CHANNEL
------------
• Select a channel.
• Click "Play" to start playback.
• The channel will appear in the preview player.


SCAN
----
• Click "Scan" to check channel streams.
• The scan identifies working and unavailable streams.


DUPLICATES
----------
• Click "Duplicates" to find duplicate channels or
  duplicate stream URLs.


XTREAM
------
• Click "Xtream" to connect to an Xtream server.
• Enter the server URL, username and password.


MAC / STALKER
-------------
• Click "MAC / Stalker" for supported Stalker Portal
  connections.


THEMES
------
Open:

    Settings → Themes

Available themes:

• Dark Pro
• Ocean Blue
• Graphite
• Midnight


SAVE
----
• Click "Save" to save changes to the current playlist.
• Click "Save As" to save the playlist as a new file.


INFO
----
• Click "Info" to view the About Me and GitHub information.


============================================================
                    PLAYLIST STUDIO 5.0
============================================================