"""Load logos only for visible channel rows, without blocking the UI."""
import io
import pathlib
import queue
import urllib.parse
import urllib.request
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageTk


class RowLogos:
    def __init__(self,app):
        self.app=app;self.closed=False;self.cache=OrderedDict();self.pending=set();self.events=queue.Queue();self.pool=ThreadPoolExecutor(max_workers=3,thread_name_prefix='RowLogo')
        image=Image.new('RGBA',(32,28),'#163840');draw=ImageDraw.Draw(image);draw.rounded_rectangle((6,5,26,21),radius=3,outline='#70c8c6',width=2);draw.line((12,24,20,24),fill='#70c8c6',width=2)
        self.placeholder=ImageTk.PhotoImage(image,master=app)
        self.rows={};self.job=app.after(250,self.poll)
    def key(self,url):
        if not url:return ''
        if urllib.parse.urlsplit(url).scheme in ('http','https'):return url
        path=pathlib.Path(url)
        return str(path if path.is_absolute() else (pathlib.Path(self.app.path).parent if self.app.path else pathlib.Path.cwd())/path)
    def set_rows(self,channels):
        self.rows={c.id:self.key(c.attrs.get('tvg-logo','').strip()) for c in channels}
        for cid,key in self.rows.items():
            if self.app.table.exists(cid):self.app.table.item(cid,image=self.cache.get(key) or self.placeholder)
    @staticmethod
    def load(key,events):
        try:
            if urllib.parse.urlsplit(key).scheme in ('http','https'):
                with urllib.request.urlopen(urllib.request.Request(key,headers={'User-Agent':'PlaylistStudio/2.8.2'}),timeout=4) as response:data=response.read(4*1024*1024+1)
                if len(data)>4*1024*1024:raise ValueError('Logo too large')
                source=Image.open(io.BytesIO(data))
            else:source=Image.open(key)
            with source:
                source.thumbnail((32,28));image=source.convert('RGBA')
            events.put((key,image))
        except Exception:events.put((key,None))
    def poll(self):
        if self.closed:return
        try:
            while True:
                key,image=self.events.get_nowait();self.pending.discard(key)
                self.cache[key]=ImageTk.PhotoImage(image,master=self.app) if image else None
                for cid,url in self.rows.items():
                    if url==key and self.app.table.exists(cid):self.app.table.item(cid,image=self.cache[key] or self.placeholder)
        except queue.Empty:pass
        children=self.app.table.get_children()
        visible=[]
        if children:
            start=max(0,int(self.app.table.yview()[0]*len(children))-1)
            visible=children[start:start+max(1,self.app.table.winfo_height()//44)+3]
        for cid in visible:
            key=self.rows.get(cid,'')
            if key in self.cache:self.cache.move_to_end(key)
            elif key and key not in self.pending and len(self.pending)<3:
                self.pending.add(key);self.pool.submit(RowLogos.load,key,self.events)
        while len(self.cache)>256:
            key,_=self.cache.popitem(last=False)
            for cid,url in self.rows.items():
                if url==key and self.app.table.exists(cid):self.app.table.item(cid,image=self.placeholder)
        self.job=self.app.after(200,self.poll)
    def close(self):
        self.closed=True;self.pool.shutdown(wait=False,cancel_futures=True);self.cache.clear()
        try:self.app.after_cancel(self.job)
        except Exception:pass
