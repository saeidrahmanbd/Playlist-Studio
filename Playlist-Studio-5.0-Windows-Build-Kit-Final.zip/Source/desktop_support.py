"""Windows file drops and familiar editing menus."""
import ctypes as C
from ctypes import wintypes as W
import tkinter as tk
import queue


def editing_menu(event):
    widget = event.widget
    if widget.winfo_class() not in ('Entry', 'TEntry', 'Text', 'TCombobox'):
        return
    widget.focus_set()
    menu = tk.Menu(widget, tearoff=False)
    for label, sequence in [('Cut', '<<Cut>>'), ('Copy', '<<Copy>>'), ('Paste', '<<Paste>>')]:
        menu.add_command(label=label, command=lambda s=sequence: widget.event_generate(s))
    def select_all():
        if isinstance(widget, tk.Text):
            widget.tag_add('sel', '1.0', 'end-1c')
        else:
            widget.selection_range(0, 'end')
    menu.add_separator()
    menu.add_command(label='Select all', command=select_all)
    try:
        menu.tk_popup(event.x_root, event.y_root)
    finally:
        menu.grab_release()
    return 'break'


class FileDrops:
    """Handle Explorer WM_DROPFILES on the Tk window and native video surface."""
    def __init__(self, app):
        self.app = app
        self.handles = set()
        self.pending = queue.Queue()
        self.closed = False
        self.shell = C.WinDLL('shell32', use_last_error=True)
        self.api = C.WinDLL('comctl32', use_last_error=True)
        self.user = C.WinDLL('user32', use_last_error=True)
        self.proc_type = C.WINFUNCTYPE(C.c_ssize_t, W.HWND, W.UINT, W.WPARAM, W.LPARAM, C.c_size_t, C.c_size_t)
        self.callback = self.proc_type(self.receive)
        self.shell.DragAcceptFiles.argtypes = [W.HWND, W.BOOL]
        self.shell.DragQueryFileW.argtypes = [W.HANDLE, W.UINT, W.LPWSTR, W.UINT]
        self.shell.DragQueryFileW.restype = W.UINT
        self.shell.DragFinish.argtypes = [W.HANDLE]
        self.api.SetWindowSubclass.argtypes = [W.HWND, self.proc_type, C.c_size_t, C.c_size_t]
        self.api.SetWindowSubclass.restype = W.BOOL
        self.api.RemoveWindowSubclass.argtypes = [W.HWND, self.proc_type, C.c_size_t]
        self.api.DefSubclassProc.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
        self.api.DefSubclassProc.restype = C.c_ssize_t
        self.user.GetParent.argtypes = [W.HWND]
        self.user.GetParent.restype = W.HWND
        app.update_idletasks()
        self.register(self.user.GetParent(app.winfo_id()) or app.winfo_id())
        self.register(app.winfo_id())
        self.job = app.after(50, self.poll)

    def register(self, hwnd):
        if hwnd in self.handles:
            return
        if not self.api.SetWindowSubclass(hwnd, self.callback, 2701, 0):
            raise RuntimeError('Could not enable playlist file drops.')
        self.handles.add(hwnd)
        self.shell.DragAcceptFiles(hwnd, True)

    def receive(self, hwnd, message, wparam, lparam, subclass, data):
        if message == 0x233:
            try:
                paths = []
                for index in range(self.shell.DragQueryFileW(wparam, 0xffffffff, None, 0)):
                    size = self.shell.DragQueryFileW(wparam, index, None, 0)
                    buffer = C.create_unicode_buffer(size + 1)
                    self.shell.DragQueryFileW(wparam, index, buffer, size + 1)
                    paths.append(buffer.value)
                self.pending.put(paths)
            finally:
                self.shell.DragFinish(wparam)
            return 0
        if message == 0x82:
            self.api.RemoveWindowSubclass(hwnd, self.callback, 2701)
            self.handles.discard(hwnd)
        return self.api.DefSubclassProc(hwnd, message, wparam, lparam)

    def poll(self):
        if self.closed:
            return
        try:
            while True:
                paths = self.pending.get_nowait()
                # Windows callbacks must never enter Tcl/Tk. Process drops only
                # from a timer registered by the normal Tk event loop.
                if self.app.grab_current() is not None:
                    self.pending.put(paths)
                    break
                self.app.drop_files(paths)
        except queue.Empty:
            pass
        finally:
            if not self.closed:
                self.job = self.app.after(50, self.poll)

    def close(self):
        self.closed = True
        try:
            self.app.after_cancel(self.job)
        except tk.TclError:
            pass
        for hwnd in list(self.handles):
            self.shell.DragAcceptFiles(hwnd, False)
            self.api.RemoveWindowSubclass(hwnd, self.callback, 2701)
        self.handles.clear()
