"""Move the existing Windows video surface without restarting playback."""
import ctypes as C
from ctypes import wintypes as W
import tkinter as tk
from tkinter import ttk

class FullscreenVideo:
    def __init__(self,owner,video,on_close,build_controls,on_resize):
        self.video=video;self.closed=False;self.api=C.WinDLL('user32',use_last_error=True)
        for name,result,args in [('GetParent',W.HWND,[W.HWND]),('SetParent',W.HWND,[W.HWND,W.HWND]),('MoveWindow',W.BOOL,[W.HWND,C.c_int,C.c_int,C.c_int,C.c_int,W.BOOL]),('ShowWindow',W.BOOL,[W.HWND,C.c_int])]:
            fn=getattr(self.api,name);fn.restype=result;fn.argtypes=args
        self.hwnd=video.winfo_id();self.parent=self.api.GetParent(self.hwnd);self.pack=video.pack_info()
        siblings=video.master.pack_slaves();index=siblings.index(video)
        if index+1<len(siblings):self.pack['before']=siblings[index+1]
        self.window=tk.Toplevel(owner);self.window.title('Playlist Studio · Full screen');self.window.configure(bg='#03060c');self.window.geometry(f'800x500+{owner.winfo_rootx()}+{owner.winfo_rooty()}');self.window.attributes('-fullscreen',True)
        self.bar=ttk.Frame(self.window,padding=(16,8));self.bar.pack(side='bottom',fill='x');build_controls(self.bar)
        self.host=tk.Frame(self.window,bg='#03060c');self.host.pack(fill='both',expand=True);self.window.update_idletasks()
        self.window.bind('<Escape>',lambda e:(on_close(),'break')[1]);self.window.bind('<F11>',lambda e:(on_close(),'break')[1]);self.window.protocol('WM_DELETE_WINDOW',on_close)
        video.pack_forget();C.set_last_error(0);self.api.SetParent(self.hwnd,self.host.winfo_id())
        if C.get_last_error():
            video.pack(**self.pack);self.window.destroy();raise OSError('Could not enter full screen.')
        self.host.bind('<Configure>',lambda e:self.resize(on_resize));self.resize(on_resize);self.window.lift();self.window.focus_set()
    def resize(self,callback):
        if self.closed:return
        self.api.MoveWindow(self.hwnd,0,0,max(1,self.host.winfo_width()),max(1,self.host.winfo_height()),True);self.api.ShowWindow(self.hwnd,5);callback()
    def close(self):
        if self.closed:return
        self.closed=True;self.api.SetParent(self.hwnd,self.parent);self.video.pack(**self.pack);self.video.update_idletasks();self.api.ShowWindow(self.hwnd,5);self.window.destroy()
