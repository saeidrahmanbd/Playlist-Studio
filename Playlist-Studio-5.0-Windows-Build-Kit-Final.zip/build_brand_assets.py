from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parent
preview=root/'Source'/'bdix_preview.png'
if not preview.exists(): raise SystemExit('Missing Source\bdix_preview.png')
im=Image.open(preview).convert('RGBA')
w,h=im.size
# Use the central BDIX-IPTV creative region for the application icon.
crop=im.crop((int(w*.44),int(h*.08),int(w*.63),int(h*.40)))
crop.thumbnail((256,256),Image.Resampling.LANCZOS)
canvas=Image.new('RGBA',(256,256),(5,20,35,255));canvas.alpha_composite(crop,((256-crop.width)//2,(256-crop.height)//2))
canvas.save(root/'studio.ico',format='ICO',sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)])
print('BDIX-IPTV preview and icon ready.')
