"""Duplicate finder for Playlist Studio 5.0.

Finds channels that share the same stream URL, or the same name inside one
category. Nothing is removed automatically: the person picks what to remove and
the removal goes through the editor's normal undoable commit.
"""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
import urllib.parse

MODES = ('Same stream URL', 'Same name in the same category')


def normalize_url(url):
    text = (url or '').strip()
    if not text:
        return ''
    base, bar, headers = text.partition('|')
    base = base.strip()
    try:
        parts = urllib.parse.urlsplit(base)
        path = parts.path.rstrip('/') if parts.path not in ('', '/') else parts.path
        base = urllib.parse.urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, parts.query, ''))
    except ValueError:
        pass
    return base + ('|' + headers.strip() if bar and headers.strip() else '')


def find_duplicates(doc, mode=MODES[0]):
    """Return [(label, [channels...])] for every group of two or more."""
    groups = {}
    for channel in doc.ordered():
        if mode == MODES[0]:
            key = normalize_url(channel.url)
            if not key:
                continue
        else:
            name = channel.name.strip().casefold()
            if not name:
                continue
            key = (channel.category_id, name)
        groups.setdefault(key, []).append(channel)
    result = []
    for key, items in groups.items():
        if len(items) < 2:
            continue
        label = key if mode == MODES[0] else f'{items[0].name}  ·  {doc.category(items[0].category_id).name}'
        result.append((label, items))
    return result


class DuplicatesWindow(tk.Toplevel):
    def __init__(self, app):
        import fluent_ui
        super().__init__(app)
        self.app = app
        self.title('Duplicate finder · Playlist Studio')
        self.configure(bg=fluent_ui.PANEL)
        self.geometry('1000x620'); self.minsize(760, 440)
        self.transient(app)
        self.groups = []
        body = ttk.Frame(self, padding=18); body.pack(fill='both', expand=True)
        ttk.Label(body, text='Duplicate finder', style='Title.TLabel').pack(anchor='w')
        ttk.Label(body, text='Review each group, then remove the extras. Nothing is removed automatically, and Undo restores them.',
                  style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=(2, 12))
        row = ttk.Frame(body); row.pack(fill='x')
        self.mode = tk.StringVar(value=MODES[0])
        combo = ttk.Combobox(row, textvariable=self.mode, values=list(MODES), state='readonly', width=34)
        combo.pack(side='left'); combo.bind('<<ComboboxSelected>>', lambda e: self.refresh())
        self.summary = ttk.Label(row, text='', style='Muted.TLabel'); self.summary.pack(side='left', padx=14)
        frame = ttk.Frame(body); frame.pack(fill='both', expand=True, pady=(12, 8))
        self.tree = ttk.Treeview(frame, columns=('category', 'url'), show='tree headings', selectmode='extended')
        self.tree.heading('#0', text='Channel / group'); self.tree.column('#0', width=330, minwidth=200)
        self.tree.heading('category', text='Category'); self.tree.column('category', width=170, minwidth=100, stretch=False)
        self.tree.heading('url', text='Stream URL'); self.tree.column('url', width=460, minwidth=160)
        sv = ttk.Scrollbar(frame, orient='vertical', command=self.tree.yview); sv.pack(side='right', fill='y')
        sh = ttk.Scrollbar(frame, orient='horizontal', command=self.tree.xview); sh.pack(side='bottom', fill='x')
        self.tree.configure(yscrollcommand=sv.set, xscrollcommand=sh.set); self.tree.pack(fill='both', expand=True)
        self.tree.tag_configure('group', foreground=fluent_ui.ACCENT)
        buttons = ttk.Frame(body); buttons.pack(fill='x', pady=(6, 0))
        ttk.Button(buttons, text='Select extras (keep first of each group)', command=self.select_extras).pack(side='left')
        ttk.Button(buttons, text='Remove selected…', command=self.remove, style='Accent.TButton').pack(side='left', padx=8)
        ttk.Button(buttons, text='Close', command=self.destroy, style='Quiet.TButton').pack(side='right')
        self.refresh()

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        self.groups = find_duplicates(self.app.doc, self.mode.get())
        extras = 0
        for index, (label, items) in enumerate(self.groups):
            parent = f'group{index}'
            self.tree.insert('', 'end', iid=parent, open=True, tags=('group',),
                             text=f'{len(items)} channels · {label}'[:200])
            for channel in items:
                self.tree.insert(parent, 'end', iid=channel.id, text=channel.name,
                                 values=(self.app.doc.category(channel.category_id).name, channel.url))
            extras += len(items) - 1
        if self.groups:
            self.summary.configure(text=f'{len(self.groups):,} groups · {extras:,} extra channels')
        else:
            self.summary.configure(text='No duplicates found.')

    def select_extras(self):
        ids = [channel.id for _, items in self.groups for channel in items[1:]]
        self.tree.selection_set(ids)
        if ids:
            self.tree.see(ids[0])

    def remove(self):
        valid = {channel.id for _, items in self.groups for channel in items}
        ids = [i for i in self.tree.selection() if i in valid]
        if not ids:
            messagebox.showinfo('Duplicate finder', 'Select channels to remove first, or use “Select extras”.', parent=self)
            return
        if not self.app.resolve_form():
            return
        if not messagebox.askyesno('Remove channels', f'Remove {len(ids):,} selected channel(s) from the playlist?\n\nUndo is available.', parent=self):
            return
        gone = set(ids)

        def change():
            self.app.doc.channels = [c for c in self.app.doc.channels if c.id not in gone]
        if self.app.commit(change, f'Removed {len(ids):,} duplicate channel(s). Undo is available.'):
            self.refresh()
