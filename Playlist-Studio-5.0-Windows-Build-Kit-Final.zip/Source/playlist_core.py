"""Playlist Studio's loss-conscious M3U model. No GUI dependencies."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
import copy, json, re, uuid, urllib.request, urllib.parse, os, tempfile

def uid(): return uuid.uuid4().hex

class PlaylistError(ValueError): pass

def single(value, label):
    if '\n' in value or '\r' in value: raise PlaylistError(f'{label} must be on one line.')
    return value

def quote(value):
    value=single(str(value), 'Attribute')
    if '"' not in value: return '"'+value+'"'
    if "'" not in value: return "'"+value+"'"
    raise PlaylistError('An attribute contains both single and double quotes. Remove or URL-encode the quotation marks before exporting.')

ATTR=re.compile(r'([\w-]+)\s*=\s*(?:"([^"]*)"|\x27([^\x27]*)\x27|([^\s,]+))')
def attributes(s): return {m.group(1):next(x for x in m.groups()[1:] if x is not None) for m in ATTR.finditer(s)}

def delimiter(s):
    q=None
    for i,c in enumerate(s):
        if c in ('"',"'"):
            if q==c:q=None
            elif q is None:q=c
        elif c==',' and q is None:return i
    raise PlaylistError('A channel line is missing the comma before its name.')

@dataclass
class Category:
    name:str
    id:str=field(default_factory=uid)

@dataclass
class Channel:
    name:str
    url:str
    category_id:str
    attrs:dict=field(default_factory=dict)
    directives:list=field(default_factory=list)
    duration:str='-1'
    id:str=field(default_factory=uid)

@dataclass
class Playlist:
    categories:list[Category]=field(default_factory=list)
    channels:list[Channel]=field(default_factory=list)
    header:dict=field(default_factory=dict)
    preamble:list=field(default_factory=list)
    name:str='Untitled playlist'

    def category(self, cid): return next(c for c in self.categories if c.id==cid)
    def channel(self, cid): return next(c for c in self.channels if c.id==cid)
    def ensure_category(self,name):
        name=name.strip() or 'Uncategorized';single(name,'Category name')
        found=next((c for c in self.categories if c.name==name),None)
        if not found:found=Category(name);self.categories.append(found)
        return found.id
    def ordered(self):return [ch for cat in self.categories for ch in self.channels if ch.category_id==cat.id]
    def snapshot(self):return copy.deepcopy(self)
    def fingerprint(self):return json.dumps(asdict(self),ensure_ascii=False,sort_keys=True)
    def rename_category(self,cid,name):
        name=single(name.strip(),'Category name')
        if not name:raise PlaylistError('Enter a category name.')
        if any(c.name==name and c.id!=cid for c in self.categories):raise PlaylistError('A category with this name already exists. Move channels into it to combine the groups.')
        self.category(cid).name=name
    def move_channels(self,ids,target,before=None):
        self.category(target);moving=[c for c in self.ordered() if c.id in ids]
        rest=[c for c in self.ordered() if c.id not in ids]
        if before in ids:return
        for c in moving:c.category_id=target
        if before and any(c.id==before for c in rest):index=next(i for i,c in enumerate(rest) if c.id==before)
        else:index=max((i+1 for i,c in enumerate(rest) if c.category_id==target),default=len(rest))
        self.channels=rest[:index]+moving+rest[index:]
    def merge(self,other):
        mapping={c.id:self.ensure_category(c.name) for c in other.categories}
        for ch in other.ordered():
            ch=copy.deepcopy(ch);ch.id=uid();ch.category_id=mapping[ch.category_id];self.channels.append(ch)
        for k,v in other.header.items():
            if k in ('x-tvg-url','url-tvg','tvg-url') and self.header.get(k) and v!=self.header[k]:
                self.header[k]=','.join(dict.fromkeys(self.header[k].split(',')+v.split(',')))
            else:self.header.setdefault(k,v)
        self.preamble += [line for line in other.preamble if line not in self.preamble]

def parse(text,name='Imported playlist'):
    text=text.lstrip('\ufeff');ls=text.splitlines()
    if re.search(r'<(?:\w+:)?MPD(?:\s|>)',text[:4096]):raise PlaylistError('This is a DASH stream manifest. Add its URL as a channel, rather than importing it as a channel playlist.')
    if any(x.strip().startswith(('#EXT-X-TARGETDURATION','#EXT-X-STREAM-INF')) for x in ls):raise PlaylistError('This is an HLS stream manifest, not a list of TV channels. Use Add channel and paste the link into Stream URL.')
    if re.search(r'<!doctype\s+html|<html\b',text[:4096],re.I):raise PlaylistError('The address returned a webpage, not an M3U playlist. Use the raw/download playlist link.')
    doc=Playlist(name=name);pending=None;warnings=[]
    for no,line in enumerate(ls,1):
        line=line.strip()
        if not line:continue
        if line.startswith('#EXTM3U'):doc.header.update(attributes(line[7:]));continue
        if line.startswith('#PLAYLIST-STUDIO-NAME:'):
            try:
                value=json.loads(line.split(':',1)[1])
                if isinstance(value,str):doc.name=single(value,'Playlist name')
            except (ValueError,TypeError):warnings.append(f'Line {no}: playlist name comment could not be read.')
            continue
        if line.startswith('#PLAYLIST-STUDIO-CATEGORIES:'):
            try:
                values=json.loads(line.split(':',1)[1])
                if isinstance(values,list):
                    for v in values:
                        if isinstance(v,str):doc.ensure_category(v)
            except (ValueError,TypeError):warnings.append(f'Line {no}: category-order comment could not be read.')
            continue
        if line.startswith('#EXTINF:'):
            if pending:warnings.append(f'“{pending.name}” has no stream URL. Kept for editing.')
            try:
                split=delimiter(line);meta=line[8:split];attrs=attributes(meta);duration=re.match(r'\s*([^\s]+)',meta)
                ch=Channel(line[split+1:].strip(),'',doc.ensure_category(attrs.get('group-title','Uncategorized')),attrs,[],duration.group(1) if duration else '-1')
                if not ch.name:ch.name=attrs.get('tvg-name','Unnamed channel')
                doc.channels.append(ch);pending=ch
            except PlaylistError as ex:raise PlaylistError(f'Line {no}: {ex}') from ex
        elif line.startswith('#EXTGRP:') and pending:
            pending.category_id=doc.ensure_category(line[8:]);pending.attrs['group-title']=line[8:]
        elif line.startswith('#'):
            if pending:pending.directives.append(line)
            else:doc.preamble.append(line)
        elif pending:pending.url=line;pending=None
        else:
            # Plain M3U permits URL-only entries; preserve them instead of ignoring.
            parsed=urllib.parse.urlsplit(line)
            if parsed.scheme in ('http','https','rtsp','rtmp','udp','rtp','file'):
                label=Path(parsed.path).name or parsed.netloc or 'Channel'
                doc.channels.append(Channel(label,line,doc.ensure_category('Uncategorized')))
                warnings.append(f'Line {no}: link had no channel metadata; imported into Uncategorized.')
            else:raise PlaylistError(f'Line {no} is not a recognized playlist entry. No changes were made.')
    if pending:warnings.append(f'“{pending.name}” has no stream URL. Kept for editing.')
    if not doc.channels and not text.strip().startswith('#EXTM3U'):raise PlaylistError('No M3U channels found in this file.')
    return doc,warnings

def serialize(doc):
    out=['#EXTM3U'+(' '+' '.join(f'{k}={quote(v)}' for k,v in doc.header.items()) if doc.header else '')]
    out+=doc.preamble
    out.append('#PLAYLIST-STUDIO-NAME:'+json.dumps(single(doc.name,'Playlist name'),ensure_ascii=False))
    out.append('#PLAYLIST-STUDIO-CATEGORIES:'+json.dumps([c.name for c in doc.categories],ensure_ascii=False))
    for c in doc.ordered():
        attrs=dict(c.attrs);attrs['group-title']=doc.category(c.category_id).name
        out.append('#EXTINF:'+single(c.duration,'Duration')+(' '+' '.join(f'{k}={quote(v)}' for k,v in attrs.items()) if attrs else '')+','+single(c.name,'Channel name'))
        for directive in c.directives:
            single(directive,'Playback option')
            if not directive.startswith('#') or directive.startswith(('#EXTINF','#EXTM3U')):raise PlaylistError('Playback options must be # directives, not channel entries.')
            out.append(directive)
        out.append(single(c.url,'Stream URL'))
    return '\n'.join(out)+'\n'

def save_atomic(path,text):
    path=Path(path);temp=None
    try:
        with tempfile.NamedTemporaryFile('w',encoding='utf-8-sig',newline='\n',dir=path.parent,delete=False,suffix='.tmp') as f:temp=f.name;f.write(text)
        os.replace(temp,path)
    finally:
        if temp and os.path.exists(temp):os.unlink(temp)

def decode(data):
    try:return data.decode('utf-8-sig')
    except UnicodeDecodeError:
        try:return data.decode('utf-16') if data.startswith((b'\xff\xfe',b'\xfe\xff')) else data.decode('cp1252')
        except UnicodeDecodeError:raise PlaylistError('Unsupported text encoding. Save the playlist as UTF-8 and try again.')

def fetch_playlist(url):
    url=url.strip();parts=urllib.parse.urlsplit(url)
    if parts.scheme not in ('http','https') or not parts.hostname:raise PlaylistError('Enter a complete http:// or https:// playlist URL.')
    req=urllib.request.Request(url,headers={'User-Agent':'PlaylistStudio/1.0','Accept':'*/*','Accept-Encoding':'identity'})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:
            data=r.read(25*1024*1024+1)
            if len(data)>25*1024*1024:raise PlaylistError('This download exceeds 25 MB. Download the file yourself and use Open files.')
        return parse(decode(data),Path(parts.path).name or parts.hostname)
    except PlaylistError:raise
    except Exception as ex:raise PlaylistError(f'Could not download this playlist. {ex}') from ex

class History:
    def __init__(self,limit=30):self.past=[];self.future=[];self.limit=limit
    def record(self,doc):
        self.past.append(doc.snapshot());self.past=self.past[-self.limit:];self.future=[]
    def undo(self,doc):
        if not self.past:return doc
        self.future.append(doc.snapshot());return self.past.pop()
    def redo(self,doc):
        if not self.future:return doc
        self.past.append(doc.snapshot());return self.future.pop()
